# Sourcing UK — écran CarPlay portable 9–10 pouces

**Périmètre API (07/09/2026)** — 2 recherches de 20 résultats (`portable carplay screen`, `carpuride carplay screen`) en `en_GB/GB/GBP`, 3 `product_get`, 2 frets directs GBP. Aucun achat ni contact fournisseur.

**Résultat : TECHNICAL_WATCH.** Une offre atteint la cible économique et de délai. Pour le SKU 10 pouces, l’image de bundle de la fiche ([preuve visuelle](https://ae01.alicdn.com/kf/S182d0fd7640f4a8b97156baf756b28c3V.jpg)) déclare `Car charging`, câble, AUX, supports standard/expansion et manuel ; cela lève le manque documentaire sur l’alimentation, sans constituer une réception physique.

1. [1005009949538785](https://www.aliexpress.com/item/1005009949538785.html?skuId=12000050658540378) — SKU `12000050658540378`, **10 inches screen**, £52.19, stock déclaré 4, 133 ventes dans la recherche. CarPlay et Android Auto sans fil, supports adhésif/ventouse, compatibilité véhicule 12–24 V, haut-parleurs/AUX/FM/Bluetooth déclarés. Fret direct CN : £1.99, **4–8 jours** (11–15 septembre), rendu **£54.18**. L’image de bundle de la fiche déclare l’alimentation allume-cigare et le câble, AUX, supports et manuel. Contradiction à conserver : image **1600×600**, texte **1024×600**. La variante sélectionnée n’a pas de caméra arrière ; aucune promesse 4K/dashcam ni besoin de carte SD n’est retenu.

2. [1005009453554660](https://www.aliexpress.com/item/1005009453554660.html?skuId=12000049152281555) — SKU `12000049152281555`, **9 inch**, £53.99, stock 130, 14 ventes. CarPlay/Android Auto, supports magnétique et ventouse, Bluetooth 5.0/AUX/FM et propriété 12 V déclarés. Contradiction de fiche : une propriété affiche 7 pouces, le SKU et le détail affichent 9 pouces. Fret £1.99 mais **25–42 jours** (2–19 octobre), rendu £55.98 : délai hors cible.

3. [1005010154806308](https://www.aliexpress.com/item/1005010154806308.html?skuId=12000051344413038) — SKU `Without Rear Camera`, £44.59, stock 3, 2,000+ ventes ; écran 10/10.26 pouces selon propriétés, CarPlay/Android Auto, support adhésif et compatibilité 9–32 V. Pas de fret vérifié dans la limite de deux devis et pas de câble allume-cigare explicitement documenté.

Les trois boutiques et les devis disponibles indiquent CN. Le champ `logistics_info_dto.delivery_time=7` ne suffit pas à valider la livraison ; le fret direct est retenu. Les prix, stocks, fonctions et accessoires restent déclaratifs jusqu’à contrôle du SKU et du contenu du colis.
