# UK Search — vision nocturne loisirs (2026-09-07)

Mesure Google UK, location `2826`, langue `en`, partenaires désactivés, historique DataForSEO juillet 2026 → août 2025. Le produit envisagé est une paire numérique IR avec écran, à vendre pour faune/camping; les performances, le head-mount, la résolution et l'autonomie restent à prouver par le sourcing.

## Volumes séparés et décision de seuil

| Famille | Brut des requêtes directes et variantes proches | Prudent dédupliqué | CPC USD observés | Lecture |
|---|---:|---:|---:|---|
| Binoculars | 14 890 | **4 760** | 0,16–1,91 | sous 15 k; le brut est gonflé par synonymes à historique identique |
| Goggles | 10 650 | **9 430** | 0,10–1,61 | sous 15 k; head-mount seulement si le SKU le permet réellement |

Le brut n'est pas le seuil : `night vision binoculars`/`nite vision binoculars`/`nvg binoculars`, les variantes `best/top/good`, et les variantes IR ont le même historique mensuel et sont comptées une seule fois dans le prudent. Les familles ne sont pas additionnées : une même offre head-mountable peut recouvrir les deux intentions.

### Requêtes à cibler

**Binoculars — prudent 4 760/mois.**

| Requête | UK/mois | CPC $ | Note |
|---|---:|---:|---|
| night vision binoculars | 2 900 | 1,04 | tête large, intention mixte à filtrer |
| night vision binoculars uk | 390 | 1,07 | localisateur UK |
| digital night vision binoculars | 30 | 0,78 | très compatible avec le produit |
| infrared binoculars | 480 | 1,09 | synonyme IR; ne pas additionner ses variantes |
| night vision binoculars for wildlife | 20 | 0,16 | faune |
| best night vision binoculars | 320 | 1,91 | groupe best/top/good dédupliqué |
| night vision binoculars for sale | 140 | 0,56 | transaction |
| night binoculars | 260 | 0,88 | plus ambigu, à tester séparément |
| best night vision binoculars uk | 140 | 1,38 | intention UK + évaluation |
| night vision binoculars for hunting | 40 | 1,01 | adjacent outdoor; à garder conditionnel |
| wildlife night vision binoculars uk | 10 | — | faible mais très qualifié |
| night vision binoculars price | 20 | 0,65 | recherche prix |
| buy night vision binoculars | 10 | 1,89 | achat direct |

**Goggles — prudent 9 430/mois.**

| Requête | UK/mois | CPC $ | Note |
|---|---:|---:|---|
| night vision goggles | 8 100 | 0,46 | tête large; mélange militaire à exclure dans l'annonce |
| night vision goggles uk | 480 | 0,84 | localisateur UK |
| night vision goggles for camping | 10 | — | camping |
| night vision goggles for sale | 140 | 0,56 | transaction |
| best night vision goggles | 210 | 1,61 | groupe best/good/top dédupliqué |
| infrared night vision goggles | 170 | 0,64 | groupe IR/IR night dédupliqué |
| digital night vision goggles | 30 | 0,22 | compatible si numérique |
| night vision goggles for helmet | 50 | 0,10 | head/helmet mount; preuve SKU requise |
| head mountable night vision goggles | 30 | 1,41 | head-mount explicite |
| night vision goggles for hunting | 40 | 1,01 | adjacent outdoor |
| affordable night vision goggles | 90 | 0,47 | groupe cheap/budget dédupliqué |
| night vision goggles for watching wildlife | 10 | — | faune |
| night vision goggles price | 30 | 1,33 | prix |
| buy night vision goggles | 30 | 1,05 | achat |
| night vision goggles near me | 10 | 0,16 | intention locale faible |

À tester seulement après preuve produit : `4k night vision binoculars` (50, CPC 0,31), `rechargeable night vision binoculars` (10), `long range binoculars with night vision` (10), `best cheap night vision goggles` (50), `true night vision goggles` (70). Les termes `true`, thermal, military, PVS/Gen 3, camera/security, webcam/spy, driving glasses et marques concurrentes restent exclus du prudent.

Historique utile (ordre juillet 2026 → août 2025) : `night vision binoculars` = 1 900, 1 900, 2 400, 2 400, 2 400, 2 900, 2 900, 4 400, 5 400, 3 600, 2 900, 2 900; `night vision goggles` = 5 400, 5 400, 5 400, 5 400, 6 600, 6 600, 8 100, 12 100, 12 100, 9 900, 8 100, 8 100. Les séries complètes sont dans la preuve brute.

## SERP UK et commerçants

Les deux SERP ont été pris le 7 septembre 2026 à 11:15 UTC.

- [SERP `night vision binoculars`](https://www.google.com/search?q=night%20vision%20binoculars&hl=en&gl=GB&ie=UTF-8&uule=w+CAIQIFISCamRx0IRO1oCEXoliDJDoPjE) : niche dominante Nightfox (rang 2, digital, handheld/headmountable), Optics Warehouse (4), SW Optics (5), OneStopNature (13), Bresser (18), Night Vision Warehouse (33), Task Outdoor (41), UK Inspection Camera (46). Gros retail/marketplaces : Amazon (9), eBay (26), Menkind (44); les autres résultats sont éditoriaux, comparateurs ou guides.
- [SERP `night vision goggles`](https://www.google.com/search?q=night%20vision%20goggles&hl=en&gl=GB&ie=UTF-8&uule=w+CAIQIFISCamRx0IRO1oCEXoliDJDoPjE) : Nightfox (1) décrit des goggles numériques pour montage tête/casque; niches Night Vision Warehouse (12), Microglobe (20), Task Outdoor (41), Kaelor (48), Optics Warehouse (45), SW Optics (55). Amazon (11), eBay (38), Etsy (52) sont les places de marché. Nightmaster, TNVC, Military1st, Airrifleshop, ATN et Armasight sont fortement militaires/tactiques et ne prouvent pas l'adéquation loisir.

## Annonce texte vérifiée

La recherche Ads Transparency UK de `nightfoxstore.com` a retourné une annonce `format=text`, `verified=true`, première diffusion le 26 mai 2026 et dernière diffusion le 5 septembre 2026 : [fiche Google Ads Transparency exacte](https://adstransparency.google.com/advertiser/AR15838217882874937345/creative/CR07340395504557096961?region=GB). Le nom d'annonceur affiché est **Phong Y. Khang**; cela prouve une annonce vérifiée liée au domaine interrogé, mais pas que Nightfox est le nom légal de l'annonceur. Aucun texte créatif exploitable n'est exposé par la réponse API.

## Preuves brutes

- [keywords_for_keywords UK, 4 685 idées](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-nightvision-keywords.json>) — coût 0,09 $.
- [SERP binoculars brut](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-serp-nightvision-binoculars.json>) — coût 0,0065 $.
- [SERP goggles brut](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-serp-nightvision-goggles.json>) — coût 0,0065 $.
- [Ads Transparency brut](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-google-text-ads-nightfoxstore.com.json>) — coût 0,002 $.

Coût total des 4 appels : **0,105 $**. Aucun sourcing ni verdict de rentabilité n'est déduit de cette mesure.
