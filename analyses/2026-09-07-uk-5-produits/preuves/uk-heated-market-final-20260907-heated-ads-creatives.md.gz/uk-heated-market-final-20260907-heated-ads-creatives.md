# Ads Search Text — chauffants UK (07/09/2026)

Fenêtre 01/08/2026–07/09/2026, UK `location_code=2826`, `google_search`, format `text`, depth 20. Les JSON bruts associés sont `ororo-root-ads.json` et `gokozy-ads.json`.

## ororo.com

API: `20000 / Ok`, 4 items. Annonceur retourné : **Langis LLC** (`AR11549159053124960257`), vérifié.

| Creative URL | Première diffusion | Dernière diffusion |
|---|---|---|
| [CR12682586783507021825](https://adstransparency.google.com/advertiser/AR11549159053124960257/creative/CR12682586783507021825?region=GB) | 2025-11-28 01:01:12 UTC | 2026-09-06 19:23:14 UTC |
| [CR00557823463276937217](https://adstransparency.google.com/advertiser/AR11549159053124960257/creative/CR00557823463276937217?region=GB) | 2025-11-27 14:02:51 UTC | 2026-09-06 19:19:41 UTC |
| [CR09525844919697014785](https://adstransparency.google.com/advertiser/AR11549159053124960257/creative/CR09525844919697014785?region=GB) | 2025-11-27 23:49:44 UTC | 2026-09-06 11:29:57 UTC |
| [CR15917047850064674817](https://adstransparency.google.com/advertiser/AR11549159053124960257/creative/CR15917047850064674817?region=GB) | 2022-10-13 05:56:44 UTC | 2026-08-18 20:02:16 UTC |

## gokozywear.com

API: `40102 / No Search Results`, 0 item ; donc aucune creative URL, annonceur ou dernière diffusion à rapporter. Ce résultat ne permet pas d’inférer l’absence de campagnes.
