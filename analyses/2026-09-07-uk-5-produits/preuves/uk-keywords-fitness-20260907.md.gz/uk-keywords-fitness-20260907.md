# UK Search — ice baths & weighted vests (2026-09-07)

DataForSEO UK, location 2826, langue en, search partners false: 2 appels keyword ideas et 4 Ads Transparency. 36 requêtes finales. Le JSON garde les 12 mois (2026-07 → 2025-08); le prudent compte le maximum courant une fois par cluster et fusionne les historiques identiques. Volumes, CPC et offre sont des observations.

| Famille | n | Brut | Prudent | CPC |
|---|---:|---:|---:|---:|
| Ice baths portables | 16 | 59,520 | 29,310 | USD0.74–USD3.74 |
| Weighted vests fitness | 20 | 64,080 | 41,050 | USD0.33–USD1.38 |
| **Total** | **36** | **123,600** | **70,360** | — |

## Ice baths (16)

Format: requête|volume|CPC|moyenne12m|min–max|dernier|cluster.
ice bath|22,200|USD1.68|avg23,325|14,800–33,100|latest27,100|generic_portable_bath
ice bath tub|22,200|USD1.68|avg23,325|14,800–33,100|latest27,100|generic_portable_bath
cold plunge|6,600|USD1.88|avg6,191.7|4,400–8,100|latest8,100|generic_portable_bath
cold plunge tub|2,900|USD1.37|avg2,791.7|1,900–4,400|latest4,400|cold_plunge_tub
ice baths for sale|880|USD2.18|avg795|590–1,000|latest1,000|purchase_intent
home ice bath|720|USD1.44|avg755|480–1,000|latest880|home
ice tub|720|USD1.41|avg741.7|480–1,000|latest1,000|generic_portable_bath
inflatable ice bath|590|USD0.74|avg545|260–1,000|latest880|inflatable
portable ice bath|480|USD0.86|avg443.3|320–590|latest590|portable
ice plunge|590|USD1.59|avg549.2|390–880|latest720|ice_plunge
ice plunge tub|480|USD1.33|avg467.5|260–880|latest720|ice_plunge
ice bath recovery|260|USD1.55|avg250|170–320|latest260|recovery
outdoor ice bath|260|USD1.82|avg273.3|210–390|latest390|outdoor
best ice bath|260|USD3.74|avg278.3|140–480|latest320|comparison
cheap ice bath|170|USD0.74|avg160|70–260|latest260|price
cold plunge bath|210|USD2.10|avg203.3|140–260|latest210|cold_plunge_tub

## Weighted vests (20)

weighted vest|22,200|USD0.65|avg24,150|18,100–33,100|latest22,200|generic_vest
weight vest|22,200|USD0.65|avg24,150|18,100–33,100|latest22,200|generic_vest
weighted workout vest|260|USD1.04|avg259.2|210–390|latest210|workout_fitness
weighted fitness vest|480|USD0.77|avg456.7|320–590|latest390|workout_fitness
adjustable weighted vest|590|USD0.63|avg608.3|480–880|latest590|adjustable
weighted vest for walking|3,600|USD0.40|avg3,525|2,400–5,400|latest4,400|walking
weighted vest for running|2,400|USD0.76|avg2,541.7|1,900–3,600|latest1,900|running
weighted vest for women|5,400|USD0.33|avg5,283.3|2,900–9,900|latest6,600|women
weighted vest for men|1,900|USD0.89|avg1,925|1,300–2,400|latest2,400|men
weighted vest training|480|USD0.77|avg456.7|320–590|latest390|workout_fitness
weighted vest calisthenics|90|USD1.19|avg95|70–110|latest110|calisthenics
weighted vest crossfit|260|USD1.38|avg231.7|110–390|latest110|crossfit
weighted vest 10kg|1,300|USD0.53|avg1,155|880–1,600|latest1,000|weight_10kg
20kg weighted vest|1,300|USD0.94|avg1,350|1,000–1,900|latest1,000|weight_20kg
30kg weighted vest|480|USD1.08|avg444.2|390–590|latest390|weight_30kg
5kg weighted vest|260|USD0.34|avg275|210–390|latest260|weight_5kg
best weighted vest|590|USD1.24|avg633.3|390–880|latest480|comparison
affordable weighted vest|90|USD0.67|avg85.8|50–140|latest70|price
cheap weighted vest|90|USD0.67|avg85.8|50–140|latest70|price
weighted pushup vest|110|USD0.35|avg104.2|70–140|latest90|pushups

## Ads Google Search (2026-08-01 → 2026-09-07)

Texte exact de la prévisualisation; ellipses conservées. Résultats bruts: Polar 31, LUMI 4, Force 6, Bulldog 25.

- polar-recovery.com/ice baths|2026-09-07 08:43:38 +00:00|Next Day Delivery Available - 90 Day Money Back Guarantee — The Leading Provider of Ice Baths and Recovery Tubs for Athletes and Fitness Enthusiasts The Best Priced...|[creative](https://adstransparency.google.com/advertiser/AR07429709890643296257/creative/CR17633267733019754497?region=GB)|relevant category proof; tub/recovery demand
- polar-recovery.com/ice baths|2026-09-07 09:36:30 +00:00|Chill Down To 3°C in Summer - No Ice, No Hassle - £0.15/Day, Cheaper Tha... — Polar Recovery™ Cube Mini Chiller - Chill Down To 3°C - Without The Hassle Of Ice Bags Easy To Setup & Compatible With Other Brand's Tubs. Cheaper Than Ice, Less Than...|[creative](https://adstransparency.google.com/advertiser/AR07429709890643296257/creative/CR11150242714010779649?region=GB)|excluded: chiller/accessory; heavy equipment
- lumitherapy.co.uk/ice baths|2026-09-07 05:23:46 +00:00|LUMI Therapy Official Site - Shop the LUMI Range - Free UK Delivery — Premium ice baths, chillers and infrared saunas. Free UK delivery. 2,600+ reviews. Shop direct at LUMI Therapy. Premium recovery products, 5-star rated. Free UK delivery. Ice Baths, Saunas & More. 4.8/5 Star Rating.|[creative](https://adstransparency.google.com/advertiser/AR01428673368676106241/creative/CR12096214578124292097?region=GB)|relevant category proof; chiller/sauna also present
- force-fit.co.uk/weighted vests|2026-09-07 08:09:21 +00:00|Force Fitness | Rucking & Weighted Crossfit Training Vests & Equipment — Build real strength for real life. Force Fitness weighted vests and rucking gear help you train like the elite, stronger, more capable, ready for anything.|[creative](https://adstransparency.google.com/advertiser/AR01969251730805751809/creative/CR15260878363082883073?region=GB)|relevant weighted-vest proof
- bulldoggear.com/weighted vests|2026-09-07 09:29:46 +00:00|The UK's Leading Gym Supplier - Free Delivery - Bulldog Gear — Proud to be the UK's Leading Gym & Fitness Gear Store. Powerful Solutions for Any Budget We Offer a Range of Adjustable Weight Vests, Perfect for Barbell or Plate-Loaded Exercises. Fast Delivery. Athlete Gear Available. Integrated Gym Packages.|[creative](https://adstransparency.google.com/advertiser/AR02154688129221525505/creative/CR15288381426680987649?region=GB)|relevant generic/adjustable-vest proof

Polar Mini Chiller est exclu du bain portable sans groupe froid. LUMI est retenue pour la catégorie ice bath; son texte mentionne aussi chiller/sauna.

## Pages produit contrôlées

- [Polar tub](https://polar-recovery.com/products/polar-recovery-tub-ice-bath), 2026-09-07: £79.99 tub seul, portable/collapsible, moins de 5 min; UK gratuit, 3–5 jours; Shopify détecté. Bundles chiller exclus.
- [Force Black Weighted Vest](https://force-fit.co.uk/products/black-weighted-vest), 2026-09-07: £99.95, 7 kg, ajustable 30–63 pouces; UK £3.95 en 2–3 jours, £4.95 next-day, gratuit dès £100; Shopify détecté; garantie 5 ans, retours gratuits 60 jours.

## Raw et limites

[ice](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-ice-baths-keywords-for-keywords.json), [vest](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-weighted-vests-keywords-for-keywords.json), [Polar](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-ads-polar-recovery.json), [LUMI](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-ads-lumitherapy.json), [Force](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-ads-force-fit.json), [Bulldog](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-ads-bulldoggear.json)

Six appels, coût USD0.188. Aucune rentabilité, conversion ou performance n’est inférée; sourcing fournisseur hors périmètre.
 
