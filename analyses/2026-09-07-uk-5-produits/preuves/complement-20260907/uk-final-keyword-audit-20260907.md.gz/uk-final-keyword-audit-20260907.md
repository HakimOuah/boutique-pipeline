# Audit final mots-clés UK — 2026-09-07

Périmètre: 73 lignes `CIBLABLE` de `/tmp/boutique-recherche-uk-20260907/analyses/2026-09-07-uk-5-produits/mots-cles-a-cibler.csv`; contrôle local uniquement, sans nouvel appel API et sans modification du CSV.
Référentiel attendu: DataForSEO Google Ads, UK `location_code=2826`, langue `en`, `search_partners=false`.

## Contrôles

- Décision: 73/73 lignes sont `CIBLABLE`.
- Présence mot-clé, volume et CPC exacts dans la preuve source: 73/73 lignes; paires volume/CPC concordantes: 73/73.
- Métadonnées tâche et résultat: 73/73 lignes conformes au triplet UK/EN/false; fichiers contrôlés: 8.
- Référence métal: 14 lignes résolues contre `uk-20260907-cont2-metal-detector-expansion.json`.

## Totaux par famille

| Famille | Lignes | Brut (somme des lignes) | Prudent (somme des maxima par groupe) | Attendu |
|---|---:|---:|---:|---:|
| abaya | 8 | 44 940 | 37 000 | 37 000 |
| corset | 14 | 47 020 | 44 290 | 44 290 |
| watch | 26 | 37 800 | 19 250 | 19 250 |
| metal | 14 | 64 450 | 36 230 | 36 230 |
| chess | 11 | 34 370 | 17 460 | 17 460 |

Total toutes familles: brut **228 580**; prudent **154 230** (convention de déduplication par groupe  sans affirmation d'audiences uniques).

## Anomalies

Aucune anomalie détectée: les 73 mots-clés ont une preuve exacte, les paramètres UK/EN/false concordent, les sources déclarées concordent et les cinq sommes prudentes correspondent aux totaux attendus.

Les maxima par groupe sont une convention de prudence pour éviter de sommer les variantes proches partageant le même historique mensuel; ils ne représentent pas des audiences uniques.
