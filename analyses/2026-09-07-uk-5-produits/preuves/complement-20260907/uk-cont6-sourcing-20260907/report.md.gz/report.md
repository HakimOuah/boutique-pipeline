# UK sourcing — corsets structurés à baleines acier

Passe API bornée du 7 septembre 2026, GB/GBP : deux recherches de 20 résultats (`steel boned corset overbust`, `steel boned corset underbust`), quatre `product_get`, deux frets directs. Les références retenues sont des bustiers/corsets adultes sans marque tierce (`Brand Name=NONE`), pas des dispositifs médicaux ni simples tops souples.

## Deux SKU cotés

- **PRIMARY_OVERBUST** — `1005011724345711` SKU `12000056361525782` (M) · [AliExpress](https://www.aliexpress.com/item/1005011724345711.html?skuId=12000056361525782) · £18.29 + £1.99 fret = £20.28 rendu; 6–10 j (Sep 13 - 17) · stock 11 · Shop1104921907 Store.

Le listing est un overbust satin noir long torso. Les propriétés déclarent `Supporting material=Steel Boning`, polyester + élasthanne. Tableau structuré retourné : S 80–85 cm, **M 85–90 cm**, **L 90–95 cm**, 1XL 95–100 cm, 2XL 100–105 cm. Le champ API s’appelle `length`, mais la fiche demande de choisir selon le tour de taille : à confirmer avant publication. Image tableau : https://ae01.alicdn.com/kf/S9337fd4a596d4086a6aa3e02a9bb611cH.jpg ; photo SKU : https://ae01.alicdn.com/kf/S2f6a57f666934dacabcb82c3f1b0c1c4A.jpg.

- **PRIMARY_UNDERBUST** — `1005007308979912` SKU `12000040189579875` (M) · [AliExpress](https://www.aliexpress.com/item/1005007308979912.html?skuId=12000040189579875) · £18.89 + £1.99 fret = £20.88 rendu; 4–8 j (Sep 11 - 15) · stock 16 · Shop1103888902 Store.

Le listing est un underbust long torso satin noir. Les propriétés déclarent `bone=18 Steel Boned`, coton + polyester + élasthanne, composition satin. SKU M stock 16 et SKU L stock 5. Le tableau de tailles est présent en image dans la fiche mais aucun intervalle numérique n’est renvoyé par l’API : https://ae01.alicdn.com/kf/S62f0b628b9ed44aea62efcf3016626bf0.jpg. Photo SKU : https://ae01.alicdn.com/kf/Scac38945dbf748c6864466491dbb6c32Z.jpg.

## Backups visuels

- **BACKUP_OVERBUST_BROCADE** — `1005008395958198` SKU `12000044846941375` (M) · [AliExpress](https://www.aliexpress.com/item/1005008395958198.html?skuId=12000044846941375) · £20.59 + fret non coté dans la limite de deux appels · stock 63 · Phoenix Corset Store.

Overbust noir brocart/fleur, `Skeleton=14 Steel Boned`, M stock 63, 86 ventes, £20.59 avant fret. Tableau taille image-only; pas de fret dans la limite.

- **BACKUP_UNDERBUST_MESH** — `1005008359634617` SKU `12000060342612470` (M) · [AliExpress](https://www.aliexpress.com/item/1005008359634617.html?skuId=12000060342612470) · £13.19 + fret non coté dans la limite de deux appels · stock 999 · Phoenix Corset Store.

Underbust mesh A66-Black, M stock 999, mais la fiche ne renvoie pas de propriété explicite `Steel Boned` ni de composition acier : ne pas retenir sans vérification visuelle.

## Limites

Les deux offres cotées sont sous la cible £15–40 rendu (£20.28 et £20.88) et dans la fenêtre d’option API 4–10 jours, mais le champ `guaranteed_delivery_days=35` les contredit. Le délai reste déclaratif. Aucun échantillon, essayage, achat ou message fournisseur; tailles, baleines et composition restent à contrôler sur photo/échantillon. Les réponses brutes et URL image sont dans `evidence.json`, `manifest.json` et les `*.jsonl`.
