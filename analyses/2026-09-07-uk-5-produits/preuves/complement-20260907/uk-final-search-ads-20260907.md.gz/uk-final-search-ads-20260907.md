# UK — Search ads finales, montres et détecteurs

**Contrôle au 7 septembre 2026 (UK/GB, fenêtre Search 01-08–07-09).** Ce livrable réutilise les réponses publiques déjà sauvegardées et un contrôle HTML ciblé de la fiche Aevitas et de sa politique de livraison. Il ne conclut pas à une identité entre le produit fournisseur et Aevitas.

## Aevitas : le remontoir est bien une intention Search distincte

Les 12 créatifs Aevitas (`Gift In Time Limited`, annonceur `AR02455602815108644865`) ont été relus sur leurs previews. Huit portent explicitement sur les *watch winders* :

- [CR12040918351657041921 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR12040918351657041921?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/14629638313152889312) — dernière diffusion 06-09 18:19 UTC. **“Best Watch Winders UK – Luxury Wood Watch Winder”** ; texte : “Luxury watch storage solutions for collectors. Precision winding for all automatic brands. Maintain your luxury timepiece with our insurance-approved watch winder…”.
- [CR05653165224920875009 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR05653165224920875009?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/16624935617366917768) — 14-08 14:01 UTC. **“UK’s #1 Watch Winder Store – Best Rated UK Watch Winders”** ; texte : “Wide Range of Watch Winders & Accessories. Free UK Delivery … FedEx & Royal Mail UK. Shipped From The UK.” Les sitelinks montrent *Single* et *Double Watch Winders*.
- [CR16443010240917536769 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR16443010240917536769?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/3988340711172791236) — 14-08 11:38 UTC. **“Silent Watch Winder Tech – Luxury Watch Storage”** ; texte sur le maintien en mouvement des montres automatiques.
- [CR09427967176276443137 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR09427967176276443137?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/2286834592607773345) — 09-08 21:31 UTC. **“UK’s #1 Watch Winder Store”** ; texte “Watch Winders by Aevitas…”.
- [CR11893192092517662721 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR11893192092517662721?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/9521731745740254925) — 06-08 13:41 UTC. **“Optimal Rolex Daytona Watch Winder Settings – Aevitas”**, texte de réglage du remontoir.
- [CR07046759920653303809 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR07046759920653303809?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/11328408171183808433) — 05-08 21:28 UTC. **“UKs Best Selling Watch Winders – Amazing 4 Watch…”**, visuel d’un remontoir 4 montres et promotion jusqu’à 30 %.
- [CR10961513896745107457 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR10961513896745107457?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/4066274718731850265) — 05-08 21:10 UTC. **“The Premium Watch Winder – UKs Best Selling Watch Winders”**, avec “Free UK Delivery”.
- [CR15000116862589599745 — détail](https://adstransparency.google.com/advertiser/AR02455602815108644865/creative/CR15000116862589599745?region=GB) · [preview](https://tpc.googlesyndication.com/archive/simgad/3471820653613143169) — 05-08 20:06 UTC. **“UKs Best Selling Watch Winders – Fast Free Delivery”**, “Up to 3 Year Warranty & Free UK Delivery”.

Les quatre autres previews sont box/stockage ou voyage : [CR175… / 18423637989875741874](https://tpc.googlesyndication.com/archive/simgad/18423637989875741874), [CR125… / 17684353945219246331](https://tpc.googlesyndication.com/archive/simgad/17684353945219246331), [CR034… / 17102933954505851333](https://tpc.googlesyndication.com/archive/simgad/17102933954505851333) et [CR161… / 13016213608346045936](https://tpc.googlesyndication.com/archive/simgad/13016213608346045936). Cela appuie un univers rangement/entretien où les volumes coffret et remontoir restent comptés séparément avant addition.

### Référence retail active

[Aevitas — Single Watch Winder in Black Edition](https://aevitas-uk.co.uk/products/single-watch-winder-black?variant=41573816959139) : **£239 sale** (prix régulier £279), taxes incluses, SKU A1-Black-NEW, statut public **In stock**. Remontoir simple, alimentation secteur ou pile, 650/750/850/1000/1950 tours/jour, phase sommeil 12 h, montres jusqu’à 70 mm, adaptateurs UK/EU/USA, garantie 2 ans. Image produit : [WEBP Aevitas](https://aevitas-uk.co.uk/cdn/shop/files/Single-Watch-Winder-Black-Edition-Mains-or-Battery-by-Aevitas.webp?v=1760447310).

La fiche expose `Shopify.shop = aevitas-luxury.myshopify.com`. La [politique de livraison](https://aevitas-uk.co.uk/policies/shipping-policy) annonce taxes/droits inclus, **livraison UK Economy gratuite au-dessus de £50 en 3–5 jours ouvrés**, expédition généralement le jour même avant 15 h ; options plus rapides, dont Next Day, en supplément. Le double Solid Oak à £405 était signalé *Out of Stock* lors du contrôle, donc il ne sert pas de preuve de vente active.

## Watchmatic : preuve publicitaire hors plafond

[Annonce Watch Matic](https://adstransparency.google.com/advertiser/AR06355666362370621441/creative/CR04465575087898099713?region=GB) — [preview 6756576997278532585](https://tpc.googlesyndication.com/archive/simgad/6756576997278532585), dernière diffusion 06-09 23:59 UTC. Le preview est un coffre affiché autour de **$15,600** : présence Search réelle, mais aucun benchmark midticket pour un remontoir ou un coffret courant.

## Spin a Disc : lien Search demandé

[Spin a Disc — annonceur `spin a disc metal detectors`, créatif CR16773045432136761345](https://adstransparency.google.com/advertiser/AR08629351156142833665/creative/CR16773045432136761345?region=GB) — [preview](https://tpc.googlesyndication.com/archive/simgad/6637083503925037695), vérifié GB, dernière diffusion **07-09 09:05:45 UTC**. [Requête Ads Transparency complète](https://adstransparency.google.com/?region=GB&domain=spinadiscmetaldetectors.com&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07). Fiche retail associée déjà archivée : [Teknetics Eurotek](https://spinadiscmetaldetectors.com/products/teknetics-eurotek-metal-detector-1).

**Fichiers bruts :** `uk-20260907-cont3-aevitas-ads.json`, `uk-20260907-cont3-watchmatic-ads.json`, `uk-cont4-spinads-20260907.json` dans les dossiers de preuves mentionnés dans le brief.
