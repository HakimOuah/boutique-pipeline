## george — status 20000 Ok. — API datetime 2026-09-07 12:14:48 +00:00

1. **George Barclay England Limited** — première diffusion `2026-06-06 18:17:00 +00:00`; dernière `2026-09-07 10:14:40 +00:00`; verified `True`; creative [CR01666960585209675777](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR01666960585209675777?region=GB)

2. **George Barclay England Limited** — première diffusion `2025-07-22 19:16:58 +00:00`; dernière `2026-09-07 10:06:10 +00:00`; verified `True`; creative [CR03059613325894615041](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR03059613325894615041?region=GB)

3. **George Barclay England Limited** — première diffusion `2025-04-13 18:42:43 +00:00`; dernière `2026-09-07 09:45:19 +00:00`; verified `True`; creative [CR15195444330169892865](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR15195444330169892865?region=GB)

4. **George Barclay England Limited** — première diffusion `2026-06-28 21:07:34 +00:00`; dernière `2026-09-07 08:52:32 +00:00`; verified `True`; creative [CR01110526337694564353](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR01110526337694564353?region=GB)

5. **George Barclay England Limited** — première diffusion `2026-06-26 07:25:39 +00:00`; dernière `2026-09-07 06:23:40 +00:00`; verified `True`; creative [CR06870994199450222593](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR06870994199450222593?region=GB)

6. **George Barclay England Limited** — première diffusion `2023-02-21 12:57:48 +00:00`; dernière `2026-09-06 20:37:20 +00:00`; verified `True`; creative [CR06976802806141288449](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR06976802806141288449?region=GB)

7. **George Barclay England Limited** — première diffusion `2022-02-26 08:00:00 +00:00`; dernière `2026-09-06 20:11:49 +00:00`; verified `True`; creative [CR09927176284561997825](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR09927176284561997825?region=GB)

8. **George Barclay England Limited** — première diffusion `2022-02-25 08:00:00 +00:00`; dernière `2026-09-06 20:07:02 +00:00`; verified `True`; creative [CR00715968574342037505](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR00715968574342037505?region=GB)

9. **George Barclay England Limited** — première diffusion `2025-07-25 15:33:55 +00:00`; dernière `2026-09-06 19:48:48 +00:00`; verified `True`; creative [CR03207239048439529473](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR03207239048439529473?region=GB)

10. **George Barclay England Limited** — première diffusion `2026-08-27 09:24:14 +00:00`; dernière `2026-09-06 19:48:21 +00:00`; verified `True`; creative [CR13244608156409004033](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR13244608156409004033?region=GB)

11. **George Barclay England Limited** — première diffusion `2022-02-26 08:00:00 +00:00`; dernière `2026-09-06 18:15:49 +00:00`; verified `True`; creative [CR00386343784427814913](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR00386343784427814913?region=GB)

12. **George Barclay England Limited** — première diffusion `2026-08-14 06:27:57 +00:00`; dernière `2026-09-06 17:18:42 +00:00`; verified `True`; creative [CR10850477112263966721](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR10850477112263966721?region=GB)

13. **George Barclay England Limited** — première diffusion `2022-02-26 08:00:00 +00:00`; dernière `2026-09-06 16:37:04 +00:00`; verified `True`; creative [CR06798484491384913921](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR06798484491384913921?region=GB)

14. **George Barclay England Limited** — première diffusion `2024-04-27 15:19:34 +00:00`; dernière `2026-09-06 16:14:40 +00:00`; verified `True`; creative [CR09092937762725691393](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR09092937762725691393?region=GB)

15. **George Barclay England Limited** — première diffusion `2026-06-02 20:13:26 +00:00`; dernière `2026-09-06 15:24:31 +00:00`; verified `True`; creative [CR12043079166883528705](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR12043079166883528705?region=GB)

16. **George Barclay England Limited** — première diffusion `2023-02-21 13:17:08 +00:00`; dernière `2026-09-06 15:17:15 +00:00`; verified `True`; creative [CR10354109176384323585](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR10354109176384323585?region=GB)

17. **George Barclay England Limited** — première diffusion `2022-02-25 08:00:00 +00:00`; dernière `2026-09-06 13:55:36 +00:00`; verified `True`; creative [CR05910518900793016321](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR05910518900793016321?region=GB)

18. **George Barclay England Limited** — première diffusion `2022-02-25 08:00:00 +00:00`; dernière `2026-09-06 12:35:59 +00:00`; verified `True`; creative [CR10128172937174319105](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR10128172937174319105?region=GB)

19. **George Barclay England Limited** — première diffusion `2024-04-26 18:18:24 +00:00`; dernière `2026-09-06 12:33:38 +00:00`; verified `True`; creative [CR09671365541331206145](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR09671365541331206145?region=GB)

20. **George Barclay England Limited** — première diffusion `2026-08-24 13:07:04 +00:00`; dernière `2026-09-06 12:01:22 +00:00`; verified `True`; creative [CR07429905234345852929](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR07429905234345852929?region=GB)

21. **George Barclay England Limited** — première diffusion `2021-10-25 07:00:00 +00:00`; dernière `2026-09-06 11:15:47 +00:00`; verified `True`; creative [CR17498069635784769537](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR17498069635784769537?region=GB)

22. **George Barclay England Limited** — première diffusion `2025-04-08 22:28:13 +00:00`; dernière `2026-09-06 09:31:49 +00:00`; verified `True`; creative [CR09734160316840804353](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR09734160316840804353?region=GB)

23. **George Barclay England Limited** — première diffusion `2026-04-09 13:15:04 +00:00`; dernière `2026-08-27 09:00:50 +00:00`; verified `True`; creative [CR05963013648942104577](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR05963013648942104577?region=GB)

24. **George Barclay England Limited** — première diffusion `2026-07-17 21:37:23 +00:00`; dernière `2026-08-20 12:13:42 +00:00`; verified `True`; creative [CR14582810839313547265](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR14582810839313547265?region=GB)

25. **George Barclay England Limited** — première diffusion `2022-02-27 08:00:00 +00:00`; dernière `2026-08-16 10:49:36 +00:00`; verified `True`; creative [CR16182613924313563137](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR16182613924313563137?region=GB)

26. **George Barclay England Limited** — première diffusion `2026-06-28 21:06:27 +00:00`; dernière `2026-08-04 07:22:30 +00:00`; verified `True`; creative [CR18007799455440437249](https://adstransparency.google.com/advertiser/AR12129075192517361665/creative/CR18007799455440437249?region=GB)


## hollywood — status 20000 Ok. — API datetime 2026-09-07 12:14:57 +00:00

1. **Want Gifts ltd** — première diffusion `2021-10-25 07:00:00 +00:00`; dernière `2026-09-07 10:46:55 +00:00`; verified `True`; creative [CR09786778974796382209](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR09786778974796382209?region=GB)

2. **Want Gifts ltd** — première diffusion `2025-12-18 18:15:39 +00:00`; dernière `2026-09-07 06:16:47 +00:00`; verified `True`; creative [CR18241523535509979137](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR18241523535509979137?region=GB)

3. **Want Gifts ltd** — première diffusion `2022-08-29 18:58:06 +00:00`; dernière `2026-09-06 22:03:36 +00:00`; verified `True`; creative [CR02337419952371269633](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR02337419952371269633?region=GB)

4. **Want Gifts ltd** — première diffusion `2022-03-01 12:03:30 +00:00`; dernière `2026-09-06 20:58:16 +00:00`; verified `True`; creative [CR09298771733924282369](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR09298771733924282369?region=GB)

5. **Want Gifts ltd** — première diffusion `2024-08-12 11:04:43 +00:00`; dernière `2026-09-06 20:52:55 +00:00`; verified `True`; creative [CR14142424297443950593](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR14142424297443950593?region=GB)

6. **Want Gifts ltd** — première diffusion `2023-11-09 15:05:03 +00:00`; dernière `2026-09-06 20:38:09 +00:00`; verified `True`; creative [CR11749892699119943681](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR11749892699119943681?region=GB)

7. **Want Gifts ltd** — première diffusion `2022-08-29 19:12:15 +00:00`; dernière `2026-09-06 19:47:07 +00:00`; verified `True`; creative [CR08278780016884449281](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR08278780016884449281?region=GB)

8. **Want Gifts ltd** — première diffusion `2023-11-09 14:57:00 +00:00`; dernière `2026-09-06 19:47:07 +00:00`; verified `True`; creative [CR00333030698979950593](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR00333030698979950593?region=GB)

9. **Want Gifts ltd** — première diffusion `2024-03-11 16:37:16 +00:00`; dernière `2026-09-06 17:05:25 +00:00`; verified `True`; creative [CR14588946328944902145](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR14588946328944902145?region=GB)

10. **Want Gifts ltd** — première diffusion `2022-08-29 20:40:52 +00:00`; dernière `2026-09-06 11:49:03 +00:00`; verified `True`; creative [CR02080267547256553473](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR02080267547256553473?region=GB)

11. **Want Gifts ltd** — première diffusion `2025-12-18 18:38:03 +00:00`; dernière `2026-09-06 11:17:39 +00:00`; verified `True`; creative [CR01889833310146789377](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR01889833310146789377?region=GB)

12. **Want Gifts ltd** — première diffusion `2022-08-29 21:01:14 +00:00`; dernière `2026-09-06 09:28:03 +00:00`; verified `True`; creative [CR00325778217203924993](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR00325778217203924993?region=GB)

13. **Want Gifts ltd** — première diffusion `2024-02-28 19:00:44 +00:00`; dernière `2026-09-05 16:32:22 +00:00`; verified `True`; creative [CR02995418373866651649](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR02995418373866651649?region=GB)

14. **Want Gifts ltd** — première diffusion `2024-02-28 10:53:00 +00:00`; dernière `2026-09-04 16:23:47 +00:00`; verified `True`; creative [CR04975092993867382785](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR04975092993867382785?region=GB)

15. **Want Gifts ltd** — première diffusion `2024-02-28 08:03:47 +00:00`; dernière `2026-09-03 12:31:43 +00:00`; verified `True`; creative [CR17826510767071952897](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR17826510767071952897?region=GB)

16. **Want Gifts ltd** — première diffusion `2024-03-05 13:37:56 +00:00`; dernière `2026-08-30 17:27:39 +00:00`; verified `True`; creative [CR15386639764333527041](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR15386639764333527041?region=GB)

17. **Want Gifts ltd** — première diffusion `2024-08-12 10:36:47 +00:00`; dernière `2026-08-27 21:32:13 +00:00`; verified `True`; creative [CR07421784816988717057](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR07421784816988717057?region=GB)

18. **Want Gifts ltd** — première diffusion `2024-03-04 22:17:42 +00:00`; dernière `2026-08-19 09:15:57 +00:00`; verified `True`; creative [CR11794808960295370753](https://adstransparency.google.com/advertiser/AR05191506465948434433/creative/CR11794808960295370753?region=GB)


## mirrorstore — status 40102 No Search Results. — API datetime 2026-09-07 12:14:49 +00:00

Aucun résultat dans cette requête; cela ne prouve pas l’absence de campagnes.

