# UK sourcing — remontoir automatique 2 montres

Passe GB/GBP du 7 septembre 2026. La fiche existante `1005006786141635` ne possède qu’une variante retournée, Black, stock 2; aucune autre couleur 2 slots >5 n’était disponible dans son `product_get`. Une recherche supplémentaire (`double watch winder USB`, 20 résultats), trois nouveaux `product_get` et un fret direct ont suivi; un devis exact ultérieur a été ajouté pour la variante à fort stock.

## Offre la mieux prouvée, mais faible stock

`1005006786141635`, SKU `12000038298689118` Black — [AliExpress](https://www.aliexpress.com/item/1005006786141635.html?skuId=12000038298689118), £28.69, stock **2**, 358 ventes déclarées. Fret GB/GBP déjà obtenu £1.99, option 4–8 j (Sep 11–15), CN : **£30.68 rendu**. Image SKU : https://ae01.alicdn.com/kf/S1e4aae36caea4069984ad688c2a1e5f4O.jpg.

Le texte confirme deux emplacements/coussins amovibles, deux modes, moteur silencieux, câble USB inclus, prise murale USB non incluse et aucune batterie. PU noir, pas bois. C’est le seul dossier avec contenu et fret cohérents, mais le stock de 2 empêche une sélection robuste.

## Nouvelles pistes

- `1005007344751830`, SKU `12000040354079030` Black : £28.89, stock 2, 408 ventes. Texte très clair : deux coussins, câble USB inclus, prise murale non incluse, montres jusqu’à 42 mm. Image : https://ae01.alicdn.com/kf/S1e4aae36caea4069984ad688c2a1e5f4O.jpg. Le seul fret nouveau a renvoyé `DELIVERY_SERVICE_EXCEPTION`; aucun total/délai validé.
- `1005008107024816`, SKU `12000043796914430` W135B Black / China Mainland : £33.49, stock **9 957**. Fret direct exact GB/GBP gratuit déclaré, option **6–13 j** (Sep 13–20), total **£33.49**. Titre « Double 2+0 », PU 18×15×14 cm, USB-DC/usage power bank; câble et coussins non confirmés textuellement, aucune prise secteur promise. Image SKU issue du get : https://ae01.alicdn.com/kf/S68607c8ed09f44a096386cc0e51d1c050.jpg.
- `1005007644146607`, SKU `12000041630477333` W135B Black : £28.19, stock **15**. Texte « 2+0 USB-DC », PU extérieur/MDF intérieur, 14×16×18,5 cm; câble non confirmé et fret non coté. Image : https://ae01.alicdn.com/kf/Sc5c56fa5ef33494c9ac42735dba89809r.jpg.

## Limites

Les délais sont déclaratifs; le devis existant contient `guaranteed_delivery_days=35` malgré l’option 4–8 jours, et le nouveau devis haut-stock `guaranteed_delivery_days=60` malgré l’option 6–13 jours. Aucun achat, échantillon ou test réel. Les réponses brutes, prix, stocks, SKU et URLs image sont dans `evidence.json`, `manifest.json` et les fichiers `*.jsonl`.
