# Sourcing UK — 3 familles : poussette, mangeoire caméra, caméra faune

**Périmètre API (07/09/2026)** — 3 recherches de 20 résultats en `en_GB/GB/GBP`, 6 `product_get` (dont un échec `All SKU Unsaleable`), 3 frets directs GBP. Les URLs de photos SKU sont dans [manifest.json](./manifest.json) pour vérification visuelle par root ; aucune image n’a été téléchargée ici.

**Résultat : 2 candidats validables sous réserve des déclarations, poussette bloquée par le fret.**

**Mangeoire caméra — candidat GO déclaratif.** [1005008831874584](https://www.aliexpress.com/item/1005008831874584.html?skuId=12000046871554273), SKU `Feeder Cam`, £45.69, stock 56, 44 ventes. La fiche documente caméra 1080P, batterie intégrée 2,000mAh, panneau solaire 4W/câble 3m, WiFi 2.4G, app ATIPCAM Android/iOS, mouvement, IP66 et supports. Le SKU 64GB existe à £48.49 mais stock 5 ; le SKU sélectionné n’inclut pas de carte SD déclarée. Fret direct CN £1.99, 6–10 jours, rendu **£47.68**. Le second résultat Jooan £58.79 a échoué au `product_get` (`All SKU Unsaleable`).

**Caméra faune — candidat GO déclaratif.** [1005007903321651](https://www.aliexpress.com/item/1005007903321651.html?skuId=12000042783566915), SKU `S810WIFI`, £68.99, stock 93, 1 vente. La fiche déclare panneau solaire 1.5W, batterie Li interne 5,200mAh, WiFi/Bluetooth/app, SD jusqu’à 256GB non incluse, câble USB, fixation, manuel et IP67. Elle déclare « 8MP real CMOS » et 4K/8K ; ce sont des claims vendeur/API non testés, donc aucun label 4K natif ne doit être publié sans échantillon. Fret CN gratuit, 6–13 jours, rendu **£68.99**.

**Poussette — pas validable au délai cible.** [1005008669344944](https://www.aliexpress.com/item/1005008669344944.html?skuId=12000050507875583), SKU gris, £57.19, stock 32, 48 ventes. La fiche décrit panier détachable, châssis métal, pliage, roue avant 360°, frein arrière, panier 56×35×77cm, charge 15kg et contenu 1 poussette. Fret £1.99 mais **25–42 jours**, rendu £59.18. L’alternative [1005012314615521](https://www.aliexpress.com/item/1005012314615521.html?skuId=12000058059109629), £63.39, stock 10, n’a qu’une mention « real photos » et aucun fret vérifié.

Les montants, stocks, solar/app/SD et délais restent des déclarations API jusqu’à contrôle photo puis échantillon. Les champs `delivery_time=7` ne remplacent pas les devis directs ; tous les frets observés partent de CN.
