# Sourcing UK — miroirs USB et univers montres

**Périmètre API (07/09/2026)** — 3 recherches de 20 résultats, 5 nouveaux `product_get` (1 miroir + 4 montres), 3 frets directs GBP. Les deux miroirs de la passe précédente sont repris avec leurs preuves brutes ; les URLs photo SKU sont dans [manifest.json](./manifest.json) pour vérification root.

**Miroir : aucun GO sous £55.** Le meilleur nouveau résultat complet est [1005006404879088](https://www.aliexpress.com/item/1005006404879088.html?skuId=12000037064826646), SKU noir 30cm, £56.39, stock 180. Il déclare miroir métal/verre 30×28cm, 3 modes, dimming, rotation 360°, miroir grossissant détachable, adaptateur 12V/2A, câble 1.2m et prise 100–240V. Fret CN gratuit, 6–13 jours : rendu **£56.39**, £1.39 au-dessus de la cible. Le miroir actuel 12 ampoules `1005009302227146` reste à £41.49 mais son fret renvoie `DELIVERY_SERVICE_EXCEPTION`; l’alternative murale `1005008716524342` est £93.59.

**Remontoir : candidat USB mais stock très bas.** [1005006786141635](https://www.aliexpress.com/item/1005006786141635.html?skuId=12000038298689118), SKU noir 2 emplacements, £28.69, 358 ventes mais stock 2. Moteur japonais silencieux, deux modes, coussins amovibles et câble USB inclus ; bloc secteur USB non inclus, boîtier PU cuir. Fret CN £1.99, 4–8 jours, rendu **£30.68**. Le candidat titre « wooden USB » `1005012217866893` est £26.79, stock 197, mais la propriété API indique Leather et le détail textuel est vide.

**Coffret bois : meilleur candidat stockage.** [32839469711](https://www.aliexpress.com/item/32839469711.html?skuId=12000032606672985), SKU `Style 1 / 10 slots`, £35.09, stock 39,871, dimensions API 29.8×20.5×10.5cm. Le titre déclare solid wood, l’API wood/mixed materials ; fret CN £5.35, 6–13 jours, rendu **£40.44**. Le 12-grids MDF `1005008635238967` coûte £29.49, stock 37, sans fret vérifié.

Les prix, stocks, prises, finition et contenus restent déclaratifs jusqu’au contrôle photo puis à l’échantillon. Le champ `delivery_time` ne remplace pas les devis directs.
