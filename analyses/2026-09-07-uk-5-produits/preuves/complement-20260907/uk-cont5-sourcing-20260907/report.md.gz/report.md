# UK sourcing — détecteur de métaux adulte (AliExpress API)

Vérification bornée du 7 septembre 2026, destination GB, devise GBP : 2 recherches de 20 résultats demandés (`metal detector adults waterproof LCD` et `metal detector adult kit`; la seconde a retourné 19 lignes), 4 `product_get`, puis 2 frets directs GBP sur le meilleur listing. Le marché retourné mélangeait fortement pinpointers et modèles enfants.

## Offre à faire vérifier visuellement

- **CANDIDATE_DECLARATIVE — 1005009126691172 / SKU `12000050720365393` (14:350850#With Accessories)** — [AliExpress](https://www.aliexpress.com/item/1005009126691172.html?skuId=12000050720365393) · £26.49 + £1.99 fret = **£28.48** · stock déclaré 865 · expédition CN · option 6–10 j (Sep 13 - 17).

Le texte du listing confirme un détecteur réglable avec bobine de recherche, écran LCD + son, mode “All Metal”, profondeur annoncée 10–100 cm, bobine étanche et pile 9V **non incluse**. La variante s’appelle “With Accessories”, mais l’API ne détaille ni pelle, ni casque, ni sac. Le titre/les images et le colis de 47 cm suggèrent un détecteur à canne, mais l’usage adulte et le contenu physique restent à valider par photo/échantillon. L’écran et le compartiment batterie ne sont pas étanches selon la fiche.

- **ALTERNATIVE_LOW_STOCK — 1005009126691172 / SKU `12000048435221831` (14:350686#with accessories)** — [AliExpress](https://www.aliexpress.com/item/1005009126691172.html?skuId=12000048435221831) · £23.99 + £1.99 fret = **£25.98** · stock déclaré 6 · expédition CN · option 4–8 j (Sep 11 - 15).

Même produit/claims, avec seulement 6 unités déclarées et une fenêtre API plus courte (4–8 j). Il s’agit d’une alternative de stock, pas d’un second vendeur.

## Écartés

- `1005010183718844` — SKU `12000051436329866`, £16.89, stock 1 : texte “can be used with a ground metal detector”, localisation de proximité/induction coil, 410 mm/313 g; pinpointer/utility locator, pas de canne complète.
- `1005009205106930` — £46.09, stock 4/2 : handheld IP68, LCD = No, longueur réglable = No, lanyard/USB; pas de détecteur adulte complet.
- `1005007292344306` — SKU `12000040089255615`, £16.19, stock 15 : handheld GT-120, bobine 4.2", LCD = No, pile non incluse, bracelet; écarté.

## Devis remontoir demandé en complément

`1005012217866893`, SKU `12000057777061832` `CC-J-B1` — [fiche](https://www.aliexpress.com/item/1005012217866893.html?skuId=12000057777061832), £26.79, stock 197, fret GBP £1.99, total **£28.78**, option 6–10 j (Sep 13–17), CN. Contrôle visuel communiqué par root : image `https://ae01.alicdn.com/kf/Sdf8eebfb9f5e4e0682cff0460a08b1f0y.jpg` montrant “1+0” et un coussin, probablement une seule position; finition PU/cuir noir, aucun bois apparent. La propriété API est `Material=Leather`, le texte produit est vide; USB est dans le titre, câble/prise UK non prouvés. Ne pas présenter comme coffret bois deux montres.

## Limites

Les délais sont déclaratifs et contradictoires dans le devis : `guaranteed_delivery_days=35` alors que l’option indique `max_delivery_days=8/10` et une date. Aucun achat, échantillon, contrôle physique ou message fournisseur. Les URL d’images et les réponses brutes sont dans `manifest.json`, `evidence.json` et les fichiers `*.jsonl`.
