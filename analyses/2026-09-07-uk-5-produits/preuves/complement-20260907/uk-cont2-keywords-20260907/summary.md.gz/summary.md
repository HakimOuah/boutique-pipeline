# UK Search continuation 2 — 2026-09-07

Mesure UK Google Ads (`location_code=2826`, `language_code=en`, `search_partners=false`) sans reprise des cinq familles précédentes. Le batch initial couvre les 35 seeds demandés. Les trois expansions principales ont été appliquées aux familles product-led les plus fortes : record players, dog beds et digital photo frames. Le supplément autorisé a ensuite mesuré metal detectors; l'expansion mirrors a retourné `50301 Too many requests` à coût nul, donc les cinq seeds miroirs restent la preuve disponible.

## Batch initial

Les plus fortes racines product-led sont `record player` **74 000/mois** (CPC $0,49), `dog bed` **60 500** ($0,79), `digital photo frame` **27 100** ($0,64) et `metal detector` **27 100** ($1,01). Les miroirs ont trois seeds à 18 100 : `dressing table mirror` ($0,79), `hollywood mirror` ($0,51) et `bathroom mirror with lights` ($1,84); `vanity mirror with lights` est à 8 100. Le metal detector a été gardé hors du trio initial uniquement à cause du plafond de trois expansions, puis ajouté au supplément.

Les autres seeds restent en dessous ou dans des familles distinctes : dog stroller/pram 6 600 chacun, cat wheel 6 600, wildlife camera 8 100, watch box 8 100, turntable 14 800 mais sans l'expansion record player, weaving loom 1 900 et tufting gun 1 300. Backgammon n'a pas de volume retourné.

## Expansions et totaux

Les totaux ci-dessous additionnent seulement les lignes `INCLUS` des CSV. Le brut conserve les variantes proches; le prudent garde une seule requête par historique mensuel identique. Le total sans racine retire le head term principal; il ne constitue pas une prévision de ventes.

| Famille | Brut inclus | Prudent dédupliqué | Sans racine | CPC observés |
|---|---:|---:|---:|---:|
| Record players | 210 830 | **164 130** | **90 130** | $0,25–1,14 |
| Dog beds | 201 880 | **120 480** | **59 980** | $0,29–3,10 |
| Digital photo frames | 73 780 | **42 140** | **15 040** | $0,42–1,63 |
| Metal detectors | 67 100 | **38 290** | **11 190** | $0,33–1,93 |

Ces sommes sont des enveloppes de requêtes par famille : elles ne doivent pas être attribuées à un SKU unique quand elles mélangent taille, fonctionnalité, style ou accessoires. Les CSV détaillent les clusters et les exclusions.

### Anomalie de preuve

`photo frame digital` vaut **880 / CPC $0,75** dans le batch `search_volume/live`, mais **27 100 / CPC $0,64** dans l'expansion `keywords_for_keywords/live`. Les deux lignes sont conservées en `DATA_CONFLICT` dans le CSV et ne sont pas comptées comme un volume additionnel prudent. Le total frame conserve un seul head term à 27 100.

## Exclusions fortes

Les CSV écartent notamment stands/accessoires et bundles de disques pour les record players, cooling mats/covers et marques/retailers pour les dog beds, marques/retailers/services pour les frames, puis pinpointers, location, enfants, industriel/médical, marques et retailers pour les metal detectors. Les termes miroirs n'ont pas reçu d'expansion payante exploitable.

## Fichiers et preuves

- [Seed screen 35 termes](/tmp/uk-cont2-keywords-20260907/seed-screen.csv)
- [Record players](/tmp/uk-cont2-keywords-20260907/record-player.csv)
- [Dog beds](/tmp/uk-cont2-keywords-20260907/dog-bed.csv)
- [Digital photo frames](/tmp/uk-cont2-keywords-20260907/digital-photo-frame.csv)
- [Metal detectors](/tmp/uk-cont2-keywords-20260907/metal-detector.csv)
- [Preuves brutes initiales](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-seeds-search-volume.json>)
- [Preuve expansion record player](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-record-player-expansion.json>)
- [Preuve expansion dog bed](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-dog-bed-expansion.json>)
- [Preuve expansion digital frame](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-digital-photo-frame-expansion.json>)
- [Preuve supplément metal detector](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-metal-detector-expansion.json>)
- [Réponse miroir 50301 sans coût](</Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont2-mirror-expansion.json>)

Les coûts visibles dans les preuves sont $0,09 pour le batch initial, $0,09 par expansion réussie et $0 pour la réponse miroir 50301; soit **$0,45** de tâches facturées visibles.
