# Ads Search Text — concurrence UK (07/09/2026)

Fenêtre 01/08/2026–07/09/2026, UK `location_code=2826`, `google_search`, format `text`, profondeur 20.

## green-feathers.co.uk

Statut API : `20000 / Ok.` ; items `19` ; [check URL](https://adstransparency.google.com/?region=GB&domain=green-feathers.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07).

| Annonceur | Creative URL | Première diffusion | Dernière diffusion |
|---|---|---|---|
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR11412730937385943041](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR11412730937385943041?region=GB) | 2026-06-04 14:06:37 +00:00 | 2026-09-07 10:33:01 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR01904644650895933441](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR01904644650895933441?region=GB) | 2024-05-08 11:00:04 +00:00 | 2026-09-07 06:30:56 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR04451332091581300737](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR04451332091581300737?region=GB) | 2025-04-10 14:42:13 +00:00 | 2026-09-07 04:26:59 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR13782557921244086273](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR13782557921244086273?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-09-07 01:23:05 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR17514230910524850177](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR17514230910524850177?region=GB) | 2024-05-08 10:14:55 +00:00 | 2026-09-06 23:59:41 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR09547181956446289921](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR09547181956446289921?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-09-06 22:27:37 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR13550319075225239553](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR13550319075225239553?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-09-06 22:27:37 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR05757809620596817921](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR05757809620596817921?region=GB) | 2024-01-09 08:00:00 +00:00 | 2026-09-06 22:14:22 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR05287313356527501313](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR05287313356527501313?region=GB) | 2025-10-02 00:36:11 +00:00 | 2026-09-06 21:09:43 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR16598105564425224193](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR16598105564425224193?region=GB) | 2025-09-24 20:30:02 +00:00 | 2026-09-06 20:16:15 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR07482096963962273793](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR07482096963962273793?region=GB) | 2025-04-10 18:06:02 +00:00 | 2026-09-06 19:17:32 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR08695066492233842689](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR08695066492233842689?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-09-06 17:28:54 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR08874760227317088257](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR08874760227317088257?region=GB) | 2022-11-24 15:57:50 +00:00 | 2026-09-06 16:14:23 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR13409009909542944769](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR13409009909542944769?region=GB) | 2024-05-28 15:08:02 +00:00 | 2026-08-18 21:53:51 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR17035540656308617217](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR17035540656308617217?region=GB) | 2024-05-28 18:00:17 +00:00 | 2026-08-18 21:53:51 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR01111990955902238721](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR01111990955902238721?region=GB) | 2026-01-13 13:44:26 +00:00 | 2026-08-18 21:02:04 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR13089808876407095297](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR13089808876407095297?region=GB) | 2026-01-14 12:24:41 +00:00 | 2026-08-18 20:04:25 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR09939276599004233729](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR09939276599004233729?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-08-18 11:01:00 +00:00 |
| Open 24 Seven Ltd. (`AR16258411816391016449`) | [CR14515602392201822209](https://adstransparency.google.com/advertiser/AR16258411816391016449/creative/CR14515602392201822209?region=GB) | 2024-01-08 08:00:00 +00:00 | 2026-08-18 10:52:55 +00:00 |

## k9wagons.co.uk

Statut API : `20000 / Ok.` ; items `4` ; [check URL](https://adstransparency.google.com/?region=GB&domain=k9wagons.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07).

| Annonceur | Creative URL | Première diffusion | Dernière diffusion |
|---|---|---|---|
| K9 Wagons Ltd (`AR17288203497749086209`) | [CR10443996803165585409](https://adstransparency.google.com/advertiser/AR17288203497749086209/creative/CR10443996803165585409?region=GB) | 2026-01-30 17:53:32 +00:00 | 2026-09-06 15:02:16 +00:00 |
| K9 Wagons Ltd (`AR17288203497749086209`) | [CR02946650832696770561](https://adstransparency.google.com/advertiser/AR17288203497749086209/creative/CR02946650832696770561?region=GB) | 2025-12-06 14:22:34 +00:00 | 2026-09-06 14:36:58 +00:00 |
| K9 Wagons Ltd (`AR17288203497749086209`) | [CR10308299063795122177](https://adstransparency.google.com/advertiser/AR17288203497749086209/creative/CR10308299063795122177?region=GB) | 2025-11-30 16:11:54 +00:00 | 2026-09-06 12:49:34 +00:00 |
| K9 Wagons Ltd (`AR17288203497749086209`) | [CR16774576905805365249](https://adstransparency.google.com/advertiser/AR17288203497749086209/creative/CR16774576905805365249?region=GB) | 2026-02-01 09:56:54 +00:00 | 2026-09-06 06:16:53 +00:00 |
