# Métal detector — contrôle commercial UK (2026-09-07)

## Décision

**Réserve / test seulement, pas GO validé.** Le marché accepte des détecteurs complets de débutant autour de **£99–199**, mais la SERP Shopping place aussi beaucoup de modèles génériques à **£16.69–59.99** chez Argos, Smyths, B&Q, Amazon et The Range. Les deux spécialistes Shopify contrôlés donnent des références retail crédibles à £119 et £159, ainsi qu’une livraison UK claire. Il manque toujours le SKU fournisseur exact, le coût rendu et la preuve que le produit source est identique : la marge ne peut donc pas être validée. La présence TT de `lmsmetaldetecting.store` et de best-sellers Minelab est une piste d’origine, pas une preuve de dropshipping.

## Demande et concurrence

Deux snapshots Google UK (desktop, anglais, location code 2826) ont été pris le **2026-09-07 à 12:19 UTC** pour [metal detector](https://www.google.com/search?q=metal+detector&gl=gb&hl=en) et [metal detector for beginners](https://www.google.com/search?q=metal+detector+for+beginners&gl=gb&hl=en). Les résultats organiques font ressortir LP Metal Detecting, UK Metal Detectors, Regton, Crawfords, Duchy, Joan Allen et Spin a Disc. Aucun bloc `paid` n’était présent dans ces deux réponses ; les cartes produit dominaient la visibilité commerciale.

Prix relevés dans le brut DataForSEO (`uk-cont4-metal-detector-serp-20260907.json` et `uk-cont4-metal-detector-beginners-serp-20260907.json`) : Argos Science Mad £25, Smyths National Geographic £49.99, B&Q £24.99–49.99, Amazon MYLEK £47.99, The Range Costway £42.95 ; références de marque débutant : Minelab Go-Find 22 £129, Go-Find 11 £99, Go-Find 66 £199, Vanquish 340 £199.

## Références spécialistes

- **[Spin a Disc — Teknetics Eurotek Metal Detector](https://spinadiscmetaldetectors.com/products/teknetics-eurotek-metal-detector-1)** : **£119** en GBP, prix barré £190. Référence active exposant Add to cart et `available=true`; détecteur complet Teknetics (Target-ID, identification fer, audio, 7.81 kHz, disque 8", poids 1.077 kg, modes discrimination/all-metal, alimentation 1×9V). Photo publique : [JPG](https://spinadiscmetaldetectors.com/cdn/shop/files/Screenshot-20240830_145319.jpg?v=1725026023). Marqueur technique HTML : `Shopify.shop = "spin-a-disc-md.myshopify.com"`. [Livraison](https://spinadiscmetaldetectors.com/policies/shipping-policy) : expédition le jour ouvré même avant 14h ; DPD lendemain gratuit UK mainland au-dessus de £50, £5.95 sous £50. L’annonceur dispose d’au moins huit créations Search vérifiées ; voir [annex Ads](uk-cont4-concurrents-20260907/ads-creatives.md).

- **[Detectorist Direct — Minelab Go-Find 22 + carry bag](https://detectoristdirect.co.uk/products/minelab-go-find-22-with-free-carry-bag)** : **£159**, variante unique, produit `.js` `available=true` et bouton Add to cart. Le texte public décrit un modèle débutant, 1 kg, étanche 22 m, modes Park/Field/Beach, avec sac offert, bobine et accessoires. Photo : [JPG](https://detectoristdirect.co.uk/cdn/shop/files/go-find22-bag-1256x1256_0beff631-3c27-4a35-9cac-0e60a6280aaf.jpg?v=1769027115). Marqueur : `Shopify.shop = "d3bdc4-1f.myshopify.com"`. **Incohérence stock à revalider** : le HTML affiche simultanément un badge « Sold out », alors que le JSON produit expose `available=true` et Add to cart. [Livraison](https://detectoristdirect.co.uk/pages/shipping-policy) : confirmation fournisseur après commande, dispatch sous 2 jours ouvrés si disponible, tracking sous 24 h, objectif 2–4 jours ouvrés, UK mainland + Northern Ireland.

Ce sont des **comparables retail** ; Teknetics et Minelab sont des marques identifiées. Shopify prouve la plateforme, jamais à lui seul une exécution dropship ni l’identité d’un fournisseur.

## Ads et inconnues

Le contrôle Ads Search texte a trouvé une vraie diffusion récente pour Spin a Disc : annonceur `spin a disc metal detectors`, creative `CR16773045432136761345`, dernière diffusion **2026-09-07 09:05 UTC** ; liens et seconde création dans [l’annexe](uk-cont4-concurrents-20260907/ads-creatives.md). Detectorist Direct a renvoyé `No Search Results` (40102), ce qui ne prouve pas l’absence de campagnes.

À vérifier avant toute décision : SKU fournisseur exact, coût rendu GB, conformité/performance réelle de détection, stock checkout et marge après TVA, paiement, SAV, retours et acquisition. Aucun de ces points ne doit être déduit du marqueur Shopify.

## Contrôle TX-850 exact (complément)

[Quildinc — TX-850](https://quildinc.co.uk/products/tx-850-metal-detector-underground-professional-depth-2-5m-scanner-search-finder-1) est bien Shopify (`quildinc.myshopify.com`), **£290.99** (prix barré £363.74), disponible avec « only 1 left in stock ». Sa fiche reprend `model TX-850`, LCD, batterie, origine Mainland China/China et profondeur marketing 2.5M ; le vendeur indiqué dans le JSON produit est `Ebay`. La fiche ne donne pas de délai ou coût UK exploitable au-delà d’un intitulé « SHIPPING ». [Photo](https://quildinc.co.uk/cdn/shop/files/v--1777899990__-1424893400_1200x1200.jpg?v=1768068568). Le contrôle Ads Search texte UK de Quildinc sur 01/08–07/09 a renvoyé `40102 No Search Results` (raw `uk-cont4-quildinc-ads-20260907.json`). Ce £290.99 est donc un outlier retail et ne doit pas servir de plafond : identité fournisseur, promesse UK et niveau de produit restent à vérifier.
