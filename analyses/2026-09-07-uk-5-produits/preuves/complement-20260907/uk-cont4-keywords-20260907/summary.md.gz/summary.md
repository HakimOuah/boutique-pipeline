# UK Search — passe 4 (2026-09-07)

Trois expansions DataForSEO Google Ads UK (location 2826, anglais, partenaires désactivés), coût déclaré $0.27. Les lignes incluses ciblent le produit; les accessoires, marques, intentions médicales, vêtements souples ou installations lourdes sont exclus dans le CSV.

## Totaux dédupliqués

| Groupe | Brut inclus | Prudent exact/proche | Brut hors tête | CPC |
|---|---:|---:|---:|---:|
| structured corset | 72 610 | 69 510 | 39 510 | $0.15–$1.37 |
| professional electric nail file | 89 840 | 18 950 | 16 030 | $0.24–$1.42 |
| practice net | 44 350 | 15 440 | 28 010 | $0.72–$1.25 |
| putting mat | 20 680 | 5 100 | 3 080 | $0.42–$1.39 |
| home training combined | 65 030 | 20 540 | 31 090 | n/a |

Le net et le tapis restent séparés; leur somme représente seulement un univers d’entraînement à domicile, sans prétendre que les deux requêtes désignent le même SKU. Le prudent fusionne les historiques mensuels identiques et les clusters de variantes proches.

## Seeds et angles retenus

- Corset : `corset` 33 100, `underbust corset` 1 900, `leather corset` 1 600, `overbust corset` 390, `steel boned corset` 320. Les tops souples, costumes complets, lingerie, médical et marques sont exclus.
- Onglerie : `electric nail file` 12 100, `nail drill` 4 400, `nail drill machine` 1 300, `professional nail drill` 590, `professional electric nail file` 390. Les bits et autres accessoires sont séparés.
- Golf : `golf net` 8 100, `putting mat` 3 600, `golf practice net` 2 900, `golf putting mat` 2 400. Les cages, cadres, netting et bundles net+mat sont exclus.

## Trends UK

Google Trends Web Search UK, comparaison unique des quatre termes, 01/01/2021–31/08/2026. L’indice est relatif et normalisé dans la comparaison; il ne remplace pas les volumes Google Ads. Les moyennes Q4 et le ratio 2025/2023 sont dans `trends-q4.csv`.

| Période | Corset | Electric nail file | Golf net | Putting mat |
|---|---:|---:|---:|---:|
| Q4 2023 | 56.33 | 1.67 | 3 | 1.33 |
| Q4 2024 | 64.33 | 1.33 | 3 | 1.67 |
| Q4 2025 | 64 | 2 | 4.67 | 1.67 |
| Q4 2025 / Q4 2023 | 1.136 | 1.198 | 1.557 | 1.256 |

Lecture Q4 : le corset reste le signal dominant; entre Q4 2023 et Q4 2025, l’indice progresse de 1.14×, l’outil onglerie de 1.20×, le golf net de 1.56× et le putting mat de 1.25×. Ces ratios décrivent la tendance relative, pas une performance commerciale.

## Fichiers et preuves

- [keywords.csv](/tmp/uk-cont4-keywords-20260907/keywords.csv)
- [trends-monthly.csv](/tmp/uk-cont4-keywords-20260907/trends-monthly.csv)
- [trends-q4.csv](/tmp/uk-cont4-keywords-20260907/trends-q4.csv)
- [URL Google Trends](/tmp/uk-cont4-keywords-20260907/trends-source.url.txt)
- [summary.json](/tmp/uk-cont4-keywords-20260907/summary.json)
- [Raw corset](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont4-corset-expansion.json)
- [Raw nail](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont4-nail-expansion.json)
- [Raw golf](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont4-golf-expansion.json)
- [Raw Google Trends CSV](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont4-google-trends.csv)
