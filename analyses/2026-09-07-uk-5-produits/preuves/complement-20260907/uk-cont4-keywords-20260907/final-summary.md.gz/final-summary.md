# Final SKU Search UK — 2026-09-07

Filtre final limité à deux SKU cible : corset structuré noir satin, avec requêtes steel-boned/overbust/underbust (matière, dimensions et disponibilité restent à vérifier au sourcing); coffret montres fermé bois 10 emplacements. Les lignes archivées restent visibles en `CONDITIONNEL` et ne sont pas ajoutées au prudent.

## Totaux stricts

| SKU | Brut inclus | Prudent exact/proche | Lignes | Archive conditionnelle brut / prudent |
|---|---:|---:|---:|---:|
| Corset noir satin structuré | 47 020 | 44 290 | 14 | 28 590 / 27 710 |
| Coffret bois fermé 10 emplacements | 11 340 | 9 970 | 6 | 22 120 / 12 170 |

Le prudent fusionne les historiques mensuels identiques et les clusters proches. Il ne traite pas les audiences (`for men`, `for women`) comme des demandes uniques.

## Watch : retraits explicites

`watch box with drawer`, `watch case`, `wrist watch case`, `watch case for men`, `watch and jewelry box` et `watch jewelry box` sont archivés en conditionnel. Leurs volumes ne figurent donc pas dans le strict du coffret fermé bois 10-slot.

## Saison Trends UK

Google Trends Web Search UK, comparaison unique des quatre termes, 01/01/2021–31/08/2026. Ratio = moyenne Q4 / moyenne janvier-septembre de la même année; l’indice est relatif, arrondi et non absolu.

| Terme | 2023 Q4/Jan-Sep | 2024 Q4/Jan-Sep | 2025 Q4/Jan-Sep |
|---|---:|---:|---:|
| corset | 1.061× | 1.281× | 1.239× |
| electric_nail_file | 1.071× | 0.923× | 1.2× |
| golf_net | 0.73× | 0.794× | 0.955× |
| putting_mat | 1.333× | 1.667× | 1.667× |

Le corset montre 1,061× / 1,281× / 1,239×. Le putting mat montre 1,333× / 1,667× / 1,667×. Les indices electric nail file et golf net sont très faibles (environ 1–5) dans la comparaison à quatre termes; l’arrondi empêche de déclarer une validation forte de leur saisonnalité.

## Fichiers

- [CSV final](/tmp/uk-cont4-keywords-20260907/final-sku-keywords.csv)
- [Résumé JSON](/tmp/uk-cont4-keywords-20260907/final-summary.json)
- [Séries Trends](/tmp/uk-cont4-keywords-20260907/trends-monthly.csv)
- [Raw corset](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont4-corset-expansion.json)
- [Raw watch](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont3-watch-keywords.json)
