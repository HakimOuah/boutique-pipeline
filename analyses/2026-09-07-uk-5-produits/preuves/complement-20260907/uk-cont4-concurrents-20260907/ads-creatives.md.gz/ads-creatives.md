# Google Ads Search texte — métal — snapshot 2026-09-07

Fenêtre demandée : 2026-08-01 → 2026-09-07, GB location_code 2826, Google Search, format text. Source brute : `uk-cont4-spinads-20260907.json` et `uk-cont4-detectoristads-20260907.json` dans ce dossier.

## Spin a Disc

Le contrôle Google Ads Transparency renvoie 8 créations vérifiées, annonceur `spin a disc metal detectors`, advertiser ID `AR08629351156142833665` :

- [creative CR16773045432136761345](https://adstransparency.google.com/advertiser/AR08629351156142833665/creative/CR16773045432136761345?region=GB) — first shown 2025-04-01 11:42 UTC; last shown 2026-09-07 09:05 UTC.
- [creative CR04138990524944089089](https://adstransparency.google.com/advertiser/AR08629351156142833665/creative/CR04138990524944089089?region=GB) — first shown 2025-04-01 16:24 UTC; last shown 2026-09-06 23:00 UTC.

[Query Ads Transparency](https://adstransparency.google.com/?region=GB&domain=spinadiscmetaldetectors.com&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07)

## Detectorist Direct

[Résultat brut](uk-cont4-detectoristads-20260907.json) : statut 40102 `No Search Results`, items 0. Cela ne permet pas d’inférer l’absence de campagnes.
