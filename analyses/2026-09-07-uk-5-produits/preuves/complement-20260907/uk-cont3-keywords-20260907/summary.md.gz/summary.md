# UK Search — passe 3 (2026-09-07)

Mesure DataForSEO Google Ads UK, location 2826, anglais, partenaires désactivés. Les volumes sont mensuels arrondis et le CPC est en USD. Les termes ne sont pas une preuve de performance ou de sourcing.

## Seeds C — screening, sans expansion

| Univers | Requête | Volume UK | CPC USD |
|---|---|---:|---:|
| fashion | `thobe` | 9 900 | $0.77 |
| fashion | `thobes` | 9 900 | $0.77 |
| fashion | `kaftan` | 18 100 | $0.76 |
| fashion | `kaftan dress` | 9 900 | $0.67 |
| fashion | `corset` | 33 100 | $0.54 |
| fashion | `underbust corset` | 1 900 | $0.71 |
| fashion | `overbust corset` | 390 | $0.47 |
| fashion | `kilt` | 22 200 | $0.54 |
| fashion | `utility kilt` | 590 | $0.94 |
| golf | `golf net` | 8 100 | $0.83 |
| golf | `golf practice net` | 2 900 | $0.84 |
| golf | `putting mat` | 3 600 | $0.87 |
| golf | `golf putting mat` | 2 400 | $0.88 |
| games | `backgammon set` | n/a | n/a |
| games | `dartboard cabinet` | 4 400 | $0.69 |
| beauty tools | `electric nail file` | 12 100 | $0.32 |
| beauty tools | `nail drill` | 4 400 | $0.49 |

Les plus forts seeds sont `corset` 33 100, `kilt` 22 200, `kaftan` 18 100, `electric nail file` 12 100, `thobe`/`thobes` 9 900 et `golf net` 8 100. `backgammon set` ne renvoie pas de volume exploitable. Aucune expansion C n’a été lancée.

## Mirrors — retry

Le retry a réussi (`status_code 20000`, 9 328 idées, coût déclaré $0.09). Le CSV garde les requêtes compatibles avec un miroir lumineux autonome et signale les contraintes de poids/montage. Les miroirs de salle de bains, ensembles de meubles, marques/retailers, travel/compact et grossissement sont exclus.

| Requête tête | Volume | CPC |
|---|---:|---:|
| `hollywood mirror` | 18 100 | $0.51 |
| `dressing table mirror` | 18 100 | $0.79 |
| `vanity mirror with lights` | 8 100 | $0.67 |
| `makeup mirror with lights` | 3 600 | $0.71 |
| `bathroom mirror with lights` | 18 100 | $1.84 |

## Watch — deux groupes SKU séparés

Le CSV conserve les requêtes incluses, conditionnelles et exclusions principales. Les totaux prudents dédupliquent les historiques mensuels identiques et les clusters de variantes proches. Les lignes conditionnelles sont présentées à part car elles supposent que le SKU livré combine bien coffret, stockage et remontoir.

| Groupe | Lignes strictes | Brut strict | Prudent strict | Lignes avec conditionnelles | Brut avec conditionnelles | Prudent avec conditionnelles | CPC |
|---|---:|---:|---:|---:|---:|---:|---:|
| static storage box | 28 | 33 300 | 21 880 | 28 | 33 300 | 21 880 | $0.34–$2.27 |
| double watch winder | 23 | 26 570 | 9 390 | 30 | 31 510 | 11 060 | $0.61–$3.07 |

Les exclusions demandées sont matérialisées : réparation/outils, coffres-forts, personnalisation, travel rolls/cases, marques, pocket watches et capacités de remontoir simple/4/6/8. Le head `watch winder` reste dans le groupe mais son intention est large; le produit cible demeure le double remontoir.

## Preuves et fichiers

- [Seeds C CSV](/tmp/uk-cont3-keywords-20260907/seed-screen.csv)
- [Mirrors CSV](/tmp/uk-cont3-keywords-20260907/mirror-expansion.csv)
- [Watch CSV](/tmp/uk-cont3-keywords-20260907/watch-universe.csv)
- [Résumé JSON](/tmp/uk-cont3-keywords-20260907/summary.json)
- [Raw seeds C](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont3-seeds-search-volume.json)
- [Raw mirror retry](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont3-mirror-expansion-retry.json)
- [Raw watch proof](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-20260907-cont3-watch-keywords.json)
