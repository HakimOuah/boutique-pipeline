# Chess.co.uk — contrôle de créatifs Search UK

**Date de contrôle : 7 septembre 2026.** Source existante : réponse Ads Search UK déjà archivée pour `chess.co.uk` (36 créatifs, fenêtre 01-08–07-09, annonceur Chess & Bridge Limited `AR14317334538471079937`). Aucune nouvelle collecte API n’a été effectuée. [Requête Ads Transparency archivée](https://adstransparency.google.com/?region=GB&domain=chess.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07).

## Résultat utile

Sur les six previews ciblés (les autres créatifs n’ont pas été ouverts), un seul texte parle clairement d’un produit de jeu :

- [CR11343161203154223105 — détail](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR11343161203154223105?region=GB) · [preview 8388981272231666054](https://tpc.googlesyndication.com/archive/simgad/8388981272231666054), dernière diffusion **07-09 06:18 UTC**. Texte visible : **“We Carry Chess Set Combinations and Plastic Chess Pieces.”** C’est une preuve d’offre de chess sets/pièces, mais elle porte explicitement sur le plastique ; elle ne valide pas un chess set en bois.

Contrôles négatifs / génériques :

- [CR17082245642513809409](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR17082245642513809409?region=GB) · [preview 8042374494694299045](https://tpc.googlesyndication.com/archive/simgad/8042374494694299045), dernière diffusion 07-09 08:10 UTC : “The UK's largest chess specialist, buy online or visit us in store. Expert staff will help”. Pas de set ni de bois dans le corps.
- [CR02979010928781033473](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR02979010928781033473?region=GB) · [preview 13362755998254302342](https://tpc.googlesyndication.com/archive/simgad/13362755998254302342), 06-09 21:09 UTC : même accroche de spécialiste, sans produit identifié.
- [CR08887346611798147073](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR08887346611798147073?region=GB) · [preview 15440932097776904055](https://tpc.googlesyndication.com/archive/simgad/15440932097776904055), 06-09 21:08 UTC : même accroche de spécialiste, sans produit identifié.
- [CR14062516121664225281](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR14062516121664225281?region=GB) · [preview 15969209333502629908](https://tpc.googlesyndication.com/archive/simgad/15969209333502629908), 06-09 20:23 UTC : “We Have Chess Stationery, Trophies, Medals and Badges.” Pas de chess set.
- [CR12602078806954475521](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR12602078806954475521?region=GB) · [preview 10117940828908541771](https://tpc.googlesyndication.com/archive/simgad/10117940828908541771), 06-09 19:55 UTC : même texte stationery/trophies, pas de chess set.

Le preview déjà signalé [CR14075494756918493185 / 8207689291865514019](https://tpc.googlesyndication.com/archive/simgad/8207689291865514019) reste du contenu général (stationery/trophies/software selon le contrôle existant). **Conclusion : preuve Search réelle pour l’univers chess et un texte produit pour des sets plastiques ; aucun texte “wooden chess set” confirmé dans ce contrôle borné.** Cela ne permet pas d’inférer qu’aucun des 36 créatifs ne parle de bois.

**Fichier brut utilisé :** `uk-20260907-chess-ads.json.gz` dans `/Users/Hakim/Downloads/recherche-uk-search-2026-09-07-01a06e3e/preuves/`.
