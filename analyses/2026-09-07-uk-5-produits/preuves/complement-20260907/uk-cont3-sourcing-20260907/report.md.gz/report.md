# Sourcing UK — lit XL / cadre Frameo / miroir Hollywood

**Périmètre API (07/09/2026)** — 3 recherches de 20 résultats en `en_GB/GB/GBP`, 6 `product_get` (un lit `ITEM_ID_NOT_FOUND`), 3 frets directs GBP. Les URLs de photos SKU sont dans [manifest.json](./manifest.json) pour vérification visuelle par root ; aucune image n’a été téléchargée ici.

**Deux pistes les plus prometteuses : cadre Frameo et miroir 12 ampoules, sous réserve prise/fret.**

**Cadre — candidat GO déclaratif, prise UK à vérifier.** [1005005545336780](https://www.aliexpress.com/item/1005005545336780.html?skuId=12000057139115817), SKU `BLACK built in 64GB / plug property id 201447606`, £59.19, stock 6, 1,000+ ventes. 10.1″ IPS tactile 1280×800, Frameo app, 64GB intégré, rotation, support mural/holder, adaptateur et manuel déclarés. Fret direct CN £1.99, 6–10 jours, rendu **£61.18**. L’API confirme l’adaptateur mais ne traduit pas l’identifiant de prise `201447606` : ne pas appeler UK plug avant contrôle photo.

**Miroir — kit complet déclaré, fret bloqué.** [1005009302227146](https://www.aliexpress.com/item/1005009302227146.html?skuId=12000048720354462), SKU `12 Bulbs`, £41.49, stock 35, 9 ventes. Miroir métal/verre intégré 11.8×16.1″, 12 ampoules, trois températures, variation tactile, rotation 360°, adaptateur déclaré, sans batterie ni assemblage. Le fret direct a retourné `DELIVERY_SERVICE_EXCEPTION` : aucun coût/délai rendu validable.

**Lit chien — complet mais hors délai.** [1005009119696851](https://www.aliexpress.com/item/1005009119696851.html?skuId=12000047983252996), SKU `107X76X17CM`, £50.79, stock 22, 45 ventes. Housse lavable, base antidérapante, support articulaire, lit sofa ; variantes XL 122×89×17cm à £65.99–£80.99. Fret £1.99 mais **25–42 jours**, rendu £52.78. L’autre candidat lit a échoué `ITEM_ID_NOT_FOUND`.

Les prix, stocks, prises, adaptateurs et contenus restent déclaratifs. Les champs `delivery_time=7` ne remplacent pas un devis direct ; les frets réussis partent de CN.
