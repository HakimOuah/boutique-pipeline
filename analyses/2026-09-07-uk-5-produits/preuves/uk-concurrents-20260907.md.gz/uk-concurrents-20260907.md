# Concurrence UK — contrôle borné (07/09/2026)

Contrôle en lecture seule des pages publiques et endpoints catalogue, le 7 septembre 2026 (heure France). Les prix sont ceux affichés en GBP ; la TVA est indiquée quand le site la distingue.

## 1. FitCore — Pilates board

- [Produit](https://tryfitcore.com/products/pilates-reformer) : **Pilates Board £119** (prix barré £179), couleurs Pink/Black/Purple. Le endpoint public [`/products/pilates-reformer.js`](https://tryfitcore.com/products/pilates-reformer.js) répond 200 et indique `available: true` le 07/09. La page rend toutefois aussi « Out of stock » : état stock à revalider avant test.
- **Plateforme : Shopify confirmée** par `Shopify.shop`, `myshopify`, `cdn.shopify.com` dans le HTML et [`/products.json`](https://tryfitcore.com/products.json) en 200. Cela ne prouve pas du dropshipping.
- **Comparable/sourceabilité :** le board est un format générique de home-fitness ; [Decathlon référence un MARCY Pilates Total Body Core Trainer](https://www.decathlon.co.uk/p/mp/pilates-core-trainer/cee5c8e8-7229-4601-8d41-e00a5e677d74/c3) et des ensembles reformer maison. Le fabricant, la composition exacte et la source du board FitCore restent inconnus ; l’offre différencie surtout le programme 90 jours, la communauté et les cadeaux digitaux.
- **Livraison UK :** [politique](https://tryfitcore.com/policies/shipping-policy) : traitement le jour même, gratuit, estimation **5–9 jours ouvrés**. La FAQ produit annonce ailleurs 4–7 jours depuis un entrepôt UK : promesse incohérente à vérifier.

## 2. BodyCamera.co.uk — body-worn cameras

- [Hytera GC550 32GB](https://www.bodycamera.co.uk/products/hytera-gc550-2k-mini-body-camera-32gb) : **£169 HT / £202.80 TTC**, SKU GC550-32GB, ajout au panier ; [Guardian Z5 64GB](https://www.bodycamera.co.uk/collections/body-worn-cameras-for-sports-leisure-commuting/products/guardian-z5) : **£229.99 HT / £275.99 TTC**. La collection montre aussi des modèles £169–£399 HT, donc vrai mid-ticket.
- **Plateforme : Shopify confirmée** (`Shopify.shop`, `bodycameras.myshopify.com`, `cdn.shopify.com`) et [`/products.json`](https://www.bodycamera.co.uk/products.json) en 200.
- **Comparable/sourceabilité :** références standardisées et identifiables (Hytera, Philips, Boblov), donc sourcing possible via fabricant/distributeur ; [un autre revendeur UK vend un Boblov 64GB £180.99 + VAT](https://www.radio-shop.uk/products/body-camera-64gb-with-4200mah-battery). La disponibilité, garantie et droits de distribution de chaque SKU restent à vérifier ; Shopify seul ne permet aucune conclusion logistique.
- **Livraison UK :** la [page d’accueil](https://www.bodycamera.co.uk/) promet **Free Shipping au-dessus de £150**. Aucun délai UK public clair trouvé dans les pages contrôlées : inconnue à résoudre au checkout ou auprès du service client.

## 3. Every Car Covered — housses auto ajustées

- [WeatherPRO](https://www.everycarcovered.com/pages/weatherpro-car-covers) à partir de **£165** ; le produit VW ID.3 exact [`/products/volkswagen-id3-2019-onwards-weatherpro-car-cover`](https://www.everycarcovered.com/products/volkswagen-id3-2019-onwards-weatherpro-car-cover) répond via `.js` avec **£224, disponible**. [ExtremePRO](https://www.everycarcovered.com/pages/extremepro-car-covers) : **£167.95**, annoncé en stock UK et next-day.
- **Plateforme : Shopify confirmée** (`Shopify.shop`, `myshopify`, `cdn.shopify.com`) et [`/products.json`](https://www.everycarcovered.com/products.json) en 200.
- **Comparable/sourceabilité :** produit réellement ajusté à la marque/modèle, avec patrons et fabrication à établir ; la page précise « not generic sizing ». Le tissu et la promesse sont génériques dans la catégorie, mais la matrice de patrons est le point de sourcing/commercialisation non prouvé.
- **Livraison UK :** [delivery info](https://www.everycarcovered.com/pages/delivery-information) : expédition visée sous 24 h, transporteur signé, **next day UK mainland £4.95** ; Highlands/Islands au checkout. Pas d’envoi Channel Islands/overseas.

## 4. Boot Defender — liners de coffre sur mesure

- [Toyota Land Cruiser Commercial 2025–26](https://bootdefender.co.uk/product/toyota-land-cruiser-commercial-fully-tailored-boot-liner/) : **£199.99–£369.99**, options matériau/couleur/layout/boot flap, ajout au panier.
- **Plateforme : WordPress/WooCommerce**, marqueurs `wp-content`, `wp-json`, WooCommerce ; [`/products.json`](https://bootdefender.co.uk/products.json) répond 404 (pas Shopify).
- **Comparable/sourceabilité :** made-to-order et sur mesure, avec demande de photos du coffre pour valider l’ajustement ([FAQ](https://bootdefender.co.uk/faqs/)). Ce n’est pas un produit générique expédiable sans patron. Repère UK spécialisé : [MTO UK](https://mto-uk.com/p/land-rover-fully-tailored-boot-liner/) à **£184.99**, fabriqué au UK, expédié sous 3–5 jours.
- **Livraison UK :** [shipping](https://bootdefender.co.uk/shipping-and-returns/) : mainland **£5.95, 2–4 jours ouvrés**, fabrication/expédition généralement sous 2 jours ; FAQ annonce 5–8 jours ouvrés de fabrication.

## 5. DRYBONES — robes et vestes waterproof

- [Storm waterproof short jacket](https://wearedrybones.co.uk/shop/drybones-storm-waterproof-short-jacket/) : **£120** en promotion (prix de référence £150) ; la page d’accueil affiche aussi robe longue £104 et Kizzy £112. Produit avec variantes, ajout au panier.
- **Plateforme : WordPress/WooCommerce** (`wp-content`, WooCommerce, `wp-json`) ; [`/products.json`](https://wearedrybones.co.uk/products.json) répond 404.
- **Comparable/sourceabilité :** catégorie standardisée (robe de changement/vestes waterproof), mais DRYBONES revendique des specs propres (20 000 mm, 15 000 g/m²/24 h, polyester recyclé). La marque, les tissus et la production exacte ne sont pas prouvés comme source générique. Repère UK spécialiste : [Dryrobe Advance £175](https://dryrobe.com/shop/), même usage et prix supérieur.
- **Livraison UK :** [delivery](https://wearedrybones.co.uk/delivery/) : **2–4 jours ouvrés**, gratuit au-dessus de £100, £6.99 entre £30–£100 ; next working day £8.99 avant midi. Collecte entrepôt à Stratford-upon-Avon.

## Lecture exploitable

Les cinq boutiques vendent bien des produits mid-ticket et affichent une promesse UK. Trois sont Shopify, deux WooCommerce/WordPress. Les bodycams ont les références les plus standardisées et vérifiables ; les housses/liners exigent patrons, compatibilité et fabrication sur mesure ; FitCore doit d’abord résoudre l’incohérence stock/délai ; DRYBONES dispose d’une vraie offre de marque mais la source de fabrication reste inconnue. Aucun élément observé ne suffit à qualifier une boutique de dropship.
