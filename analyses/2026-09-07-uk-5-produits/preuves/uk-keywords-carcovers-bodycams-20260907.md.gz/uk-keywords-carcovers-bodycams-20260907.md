# UK Search — car covers et bodycams (2026-09-07)

Mesure DataForSEO Google Ads, UK location 2826, anglais, search partners désactivés. Le JSON associé contient chaque requête, son CPC USD et son historique mensuel août 2025–juillet 2026 (`history_12m`, dans l’ordre 2026-07 vers 2025-08), avec moyenne, min, max et dernier volume disponible.

Le brut additionne les lignes retenues. Le prudent additionne une seule fois le maximum de chaque cluster d’intention proche : body camera/body cam/bodycam sont un même historique ; les variantes météo proches des housses sont regroupées. Les montants au-dessus de 15 000 proviennent des observations et ne forcent aucun seuil.

| Famille | Requêtes | Brut mensuel | Prudent dédupliqué | CPC USD |
|---|---:|---:|---:|---:|
| Car covers | 24 | 18 960 | 17 930 | 0,29–3,73 |
| Consumer bodycams | 24 | 39 260 | 14 650 | 0,12–6,47 |
| Total | 48 | 58 220 | 32 580 | — |

Les 24 requêtes car covers sont : car cover ; waterproof car cover ; outdoor car cover ; indoor car cover ; car cover for winter ; all weather car cover ; breathable car cover ; heavy duty car cover ; full car cover waterproof ; half car cover ; universal car cover ; car cover for small car ; large car cover ; car cover for suv ; car cover for convertible ; car cover for estate car ; car cover for hatchback ; car cover for van ; hail proof car cover ; uv resistant car cover ; car cover for summer ; frost proof car cover ; custom fit car covers ; car covers for sale.

Les 24 requêtes consumer bodycams sont : body camera ; body cam ; bodycam ; body worn camera ; body cameras for sale ; best body camera ; affordable body camera ; cheap body camera ; mini body camera ; small body camera ; personal body camera ; body camera with audio ; body camera with night vision ; body camera 4k ; clip on body camera ; waterproof body camera ; body camera for cycling ; body camera for walking ; body camera for personal safety ; personal body camera with audio ; body camera with sd card ; portable body camera ; body cam recorder ; wifi body camera.

Filtrage : sièges, pare-brise, accessoires et camping-car retirés des housses ; police/law enforcement, marques concurrentes, caché/spy, dashcams, webcams, actualités et formation retirés des bodycams. `car cover` reste large et à intention mixte ; `auto covers` a été retiré comme terme ambigu/doublon.

Preuves brutes :

- [Car covers expansion](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-carcovers-keywords-for-keywords.json)
- [Bodycams expansion](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-bodycams-keywords-for-keywords.json)
- [Car covers final search volume](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-carcovers-search-volume.json)
- [Bodycams final search volume](/Users/Hakim/Downloads/recherche-5-go-2026-09-05/preuves/uk-bodycams-search-volume.json)

Appels : 2 expansions `keywords_for_keywords/live` + 2 mesures `search_volume/live`, coût DataForSEO observé : $0,36.
