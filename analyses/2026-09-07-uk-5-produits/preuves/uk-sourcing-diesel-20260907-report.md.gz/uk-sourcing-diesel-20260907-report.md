# Sourcing UK — chauffage diesel 5 kW / Bluetooth

**Périmètre API (07/09/2026)** — 2 recherches AliExpress de 20 résultats en `en_GB/GB/GBP`, 2 `product_get`, 2 frets directs GBP. Les frais API sont déjà en GBP. Aucun achat, message fournisseur, échantillon ou certificat.

**Résultat : TECHNICAL_WATCH, aucun GO rendu vérifié.** Aucun des deux SKU n'atteint simultanément le plafond rendu de £100 et une fenêtre déclarée entièrement ≤10 jours. Aucun stock UK observé : boutique et expédition indiquent CN.

1. [1005005384614422](https://www.aliexpress.com/item/1005005384614422.html?skuId=12000035628648443) — SKU `12000035628648443`, **12V 5000W-Black**, £43.59, stock déclaré 945, 19 ventes dans la recherche. Le titre et la fiche déclarent diesel, 5,000 W et commande LCD/remote ; la fiche indique ensuite « accessories: as picture shown ». Pompe et échappement ne sont pas listés, et les petites pièces peuvent varier selon le lot. Fret direct : £61.34, 10–41 j, rendu **£104.93** ; ou £70.93, 6–13 j, rendu £114.52. `ship_from_country=CN`.

2. [1005010613825154](https://www.aliexpress.com/item/1005010613825154.html?skuId=12000052973298627) — SKU `12000052973298627`, **12v-5000W**, £68.79, stock déclaré 99, 14 ventes. Le titre dit Bluetooth/all-in-one ; la fiche détail dit contrôle manuel, 12–24 V et 2,000/5,000 W. Aucun contenu pompe, échappement ou remote n’est énuméré. Fret direct : £83.60, 10–41 j, rendu **£152.39** ; Premium £186.09, 6–11 j, rendu £254.88. `ship_from_country=CN`.

Le champ `logistics_info_dto.delivery_time=7` est contradictoire avec les devis directs et ne valide pas la livraison. Les puissances, la sécurité combustion, la conformité CE/UKCA, les émissions et la qualité restent des déclarations vendeur/API non vérifiées ; aucun certificat ou échantillon reçu. Avant toute offre £150–250, il faut obtenir une liste de contenu exacte (pompe, échappement, silencieux, commande), source UK réelle et preuves de conformité.
