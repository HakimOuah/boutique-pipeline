# Marché UK — gilet/veste chauffant adulte (07/09/2026)

## Demande et SERP

Une SERP DataForSEO `serp/google/organic/live/advanced`, `heated gilet`, UK (`location_code=2826`, desktop anglais, profondeur 20), a été exécutée le 07/09/2026 à 11:39:47 UTC. Preuve brute : [`heated-gilet-serp.json`](/tmp/uk-heated-market-final-20260907/heated-gilet-serp.json), coût **$0,0035**.

Le premier résultat marchand spécialisé est **ORORO** (collection affichée £80–250), puis New Forest Clothing (collection £13–171), Amazon (ORORO £169.99), Holland’s Country Clothing (£50–350), Therm-ic et Gokozy ; Screwfix apparaît plus bas à £50. Les cartes produits tirent aussi vers Amazon £7.99–39.99, B&Q £19.99, The Range £27.99, Mountain Warehouse £89–155.95, ToastyBody £99.99 et ORORO £159.99–229.99. La demande est donc très polarisée : générique marketplace à bas prix contre marques techniques à batterie et prix £80–230. Ce n’est pas une validation d’un produit générique à marge confortable.

## Offres spécialistes Shopify, prix et batterie

- [ORORO — Women’s Heated Fleece Gilet, Black, 4 heating zones](https://uk.ororo.com/products/heated-fleece-vest) : **£159.99 TTC**, variante M disponible au contrôle. La page décrit une batterie lithium-ion **7,4 V / 4 800 mAh incluse**, câble de charge, jusqu’à 10 h et port USB ; le chargeur secteur n’est pas inclus. Marqueur public : `Shopify.shop = ororo-uk.myshopify.com` et CDN Shopify dans [`ororo-product.html`](/tmp/uk-heated-market-final-20260907/ororo-product.html). [Shipping Info](https://uk.ororo.com/pages/shipping-info) : TVA UK 20 % incluse, traitement 24–48 h, livraison standard UK 5–10 jours ouvrés ; gratuite au-dessus de £149.99, sinon £9.99. C’est une offre réelle et précise, mais le niveau de prix est celui d’une marque établie.

- [GOKOZY — Heated Gilet for Men with Power Bank](https://www.gokozywear.com/en-gb/products/heated-vest-men) : **£99.99 TTC** en S/L au contrôle (M/XL/XXL indisponibles dans le HTML de la page localisée). La fiche détaillée annonce 5 zones, 3 niveaux, jusqu’à 8 h et `What's Included: 1* Battery Pack (10000mAh, 5V)`. Cependant le titre non traduit/les métadonnées du même HTML annoncent **12 V, 20 000 mAh, 15 zones**, et une section parle d’une batterie 12 V : spécification contradictoire à faire résoudre avant toute fiche ou sourcing. Marqueur public : `Shopify.shop = gokozy.myshopify.com` et CDN Shopify dans [`gokozy-product.html`](/tmp/uk-heated-market-final-20260907/gokozy-product.html). [Shipping policy](https://www.gokozywear.com/en-gb/policies/shipping-policy) : traitement annoncé sous 24–48 h, entrepôt le plus proche (UK possible), livraison gratuite annoncée ; aucun délai de transit UK chiffré trouvé.

Shopify prouve ici la plateforme technique uniquement. Rien dans ces pages ne prouve à lui seul un fulfillment dropshipping ou une origine fournisseur.

## Google Ads Transparency

Deux appels `serp/google/ads_search/live/advanced` supplémentaires ont ciblé les domaines racine **ororo.com** et **gokozywear.com**, UK 2826, Search texte, du 01/08/2026 au 07/09/2026, profondeur 20. Coût total **$0,004**. Preuves brutes : [`ororo-root-ads.json`](/tmp/uk-heated-market-final-20260907/ororo-root-ads.json) et [`gokozy-ads.json`](/tmp/uk-heated-market-final-20260907/gokozy-ads.json). Le tableau complet des liens est [`heated-ads-creatives.md`](/tmp/uk-heated-market-final-20260907/heated-ads-creatives.md).

- **ororo.com** : 4 creatives texte, toutes avec l’annonceur retourné **Langis LLC** (`AR11549159053124960257`), vérifié. Les dernières diffusions sont les 06/09/2026 11:29:57, 19:19:41 et 19:23:14 UTC, plus une au 18/08/2026 20:02:16 UTC. Les creative URLs et premières diffusions sont dans l’annexe ; le nom d’annonceur est rapporté tel que retourné, sans inférer son lien juridique avec ORORO.
- **gokozywear.com** : `40102 / No Search Results`, 0 item. Aucune creative URL, annonceur ou dernière diffusion disponible ; cela ne permet pas d’inférer l’absence de campagne.

## Décision exploitable

Le haut de SERP et les cartes montrent que les grandes enseignes et marketplaces imposent souvent £8–40 pour le générique ; ORORO, Gokozy, ToastyBody et Mountain Warehouse occupent le segment £90–230 avec une batterie ou une promesse technique. Un nouveau produit doit donc soit prouver une différence matérielle/sécurité/autonomie et un prix proche de £90–160, soit accepter la pression des offres Amazon/B&Q/The Range. La piste est **marché observé, mais non validée** : résoudre d’abord la contradiction batterie GOKOZY et obtenir le SKU/fret exact côté sourcing. Aucun test Ads ne doit être conclu à partir du seul `No Search Results`.
