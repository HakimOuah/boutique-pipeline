# Sourcing UK abayas — passe finale prix — 7 septembre 2026

Deux requêtes AliExpress (`embroidered abaya`, `luxury abaya`) ont renvoyé 20 résultats chacune. Trois fiches adultes ont été ouvertes; deux SKU brodés cohérents ont reçu un fret direct GBP vers GB. Aucun achat ni contact fournisseur.

## Offres retenues pour échantillonnage

- [1005012235894439](https://www.aliexpress.com/item/1005012235894439.html), Abaowedding Dress Store (CN), **13 ventes déclarées**, `Choice=yes`, adulte, décoration `Embroidery`, chiffon. SKU `12000057817723897`, Burgundy/M, stock **8**, prix **£27.89**. Fret Selection Premium **£1.99**, 6–10 jours (`Sep 13 - 17`), total **£29.88**. Le titre dit « open-front », mais une propriété dit `whether full opening=No`: à vérifier sur échantillon.
- [1005008650101896](https://www.aliexpress.com/item/1005008650101896.html), Meiya Store (CN), **5 ventes déclarées**, adulte, `Decoration=Embroidery`, `whether full opening=Yes`. SKU `12000046096249126`, Black Cardigan/M, stock **100**, prix **£29.39**. Fret standard **gratuit** (`free_shipping=true`, champs de montant nuls), 6–13 jours (`Sep 13 - 20`), total de screening **£29.39**. Le maximum de délai dépasse légèrement la cible 10 jours.

La troisième fiche ouverte, `1005012408718112`, avait £20.99 et 2 ventes, mais le titre promet une broderie alors que les propriétés déclarent `Decoration=NONE` et `Item Type=Dresses`; aucun fret n’a été consommé.

`TECHNICAL_WATCH`: les deux offres passent le coût rendu cible £40; la première passe aussi la fenêtre ≤10 jours API. Elles ne sont pas déclarées équivalentes à Elsara £85 : composition, tombé, broderie, tailles et qualité doivent être contrôlés par échantillon. Les stocks, ventes, Choice et délais restent déclaratifs.

Voir `evidence.json`, `search.jsonl`, `details.jsonl` et `freight-gbp.jsonl`.
