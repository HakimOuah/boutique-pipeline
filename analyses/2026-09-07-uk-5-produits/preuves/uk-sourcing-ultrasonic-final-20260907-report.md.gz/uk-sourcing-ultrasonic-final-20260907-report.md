# Sourcing UK — nettoyeur ultrasons compact — passe finale — 7 septembre 2026

Deux recherches AliExpress ont été exécutées (`ultrasonic cleaner UK plug`, `ultrasonic cleaner USB`), puis 3 fiches ouvertes et 2 variantes sondées en fret direct GBP vers GB. Aucun achat, adaptateur externe ou contact fournisseur.

## Constat

**Aucun SKU ne satisfait simultanément 35 W+, environ 400–800 ml, alimentation UK/USB documentée, coût rendu ≤£50 et délai API ≤10 jours.**

Quasi-offre UK : [1005013039050983](https://www.aliexpress.com/item/1005013039050983.html), SKU `12000060152027316` (2 L 60 W / 220–240 V UK Plug), stock 100, prix £40.39. La fiche décrit une cuve théorique 2 L, panier inox 304 et puissance 60/120 W (propriété 120 W; chauffage 150 W), mais le colis pèse 3,5 kg. Fret standard direct £40.21, 6–13 jours (`Sep 13 - 20`), total **£80.60**; heavy £37.49 mais 10–41 jours. Hors format et coût cible.

Quasi-offre USB : [1005010122198699](https://www.aliexpress.com/item/1005010122198699.html), SKU `12000051217763952`, stock 7, prix £9.29. Les propriétés déclarent 301–500 ml, **1 W**, 6 V; le mot USB n’apparaît que dans le titre et le détail renvoyé est vide. Fret £1.99, 4–8 jours, total **£11.28**. La puissance 35 W+ et l’alimentation USB ne sont donc pas prouvées.

La troisième fiche ouverte, `1005010241648074`, est USB dans le titre mais ne fournit ni capacité, puissance ni détail exploitable; elle n’a pas été sondée en fret.

Verdict : `TECHNICAL_FAIL` pour le cahier des charges exact; **constat commercial aucun**. Voir `evidence.json`, `search.jsonl`, `details.jsonl` et `freight-gbp.jsonl` pour les réponses brutes. `logistics_info_dto.delivery_time=7` n’a pas été utilisé comme preuve de livraison.
