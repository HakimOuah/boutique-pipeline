# Écrans CarPlay portables UK — contrôle borné (07/09/2026)

**Périmètre.** Recherche UK Google (location 2826, anglais, partenaires désactivés), neuf requêtes non brandées, une SERP `carplay screen`, puis fiches publiques Carpuride/Aoocci et deux repères retail. Données brutes : [`dataforseo-volume.json`](/tmp/uk-carplay-market-20260907/dataforseo-volume.json), [`dataforseo-serp.json`](/tmp/uk-carplay-market-20260907/dataforseo-serp.json), et HTML/JSON dans [`/tmp/uk-carplay-market-20260907/`](/tmp/uk-carplay-market-20260907/).

## Demande

DataForSEO renvoie un volume annuel et un dernier mois disponible (juillet 2026). Les neuf termes sont HIGH / index 100 ; coût volume + SERP : **$0,092**.

| Requête | annuel | juil. 2026 |
|---|---:|---:|
| carplay screen | 2 900 | 2 900 |
| portable carplay screen | 110 | 110 |
| carplay display | 50 | 40 |
| portable carplay | 140 | 140 |
| wireless carplay screen | 140 | 110 |
| apple carplay screen | 2 400 | 1 900 |
| android auto screen | 880 | 880 |
| portable android auto screen | 40 | 50 |
| carplay screen for car | 590 | 590 |

La SERP [Google UK](https://www.google.com/search?q=carplay+screen&hl=en&gl=GB) (11:22:20 UTC) met Amazon, Halfords, Road & Track, Caraudiocentre et des marketplaces. Aucun item `paid`/annonce texte n’a été retourné dans ce snapshot ; aucune preuve publique d’une annonce Carpuride ou Aoocci n’est donc attachée. Une absence ponctuelle ne prouve pas l’absence de campagne. Les cartes produits donnent un marché très bas : Amazon 10" **£59.99**, B&Q 10.26" **£51.99**, Amazon 7" **£39.99**, Steelmate **£44.99**, Royal Deals 9" **£39.99**, Lamtto 9.26" **£59.49**. Halfords apporte un repère de grande enseigne : [Simply In-Car Stereo 7"](https://www.halfords.com/technology/car-audio/apple-carplay/simply-in-car-stereo---7-inch-display-screen-495355.html) **£49.99**, sans être un 9–10".

## Marques et prix réellement publics

- **Carpuride W901 Pro, 9".** [Fiche officielle](https://carpuride.com/products/carpuride-w901-pro-portable-smart-multimedia-dual-bluetooth-dashboard-console-with-steering-wheel-control) : écran IPS 1024×600, CarPlay/Android Auto filaire et sans fil, double Bluetooth, télécommande volant ; **$279.99 en promotion** (prix barré $399.99). Le site est Shopify (`carpuride.myshopify.com`), mais même avec `country=GB&currency=GBP` il restait en USD : pas de prix GBP officiel vérifiable. Une [annonce eBay UK](https://www.ebay.co.uk/itm/167397597892) du modèle exact + caméra affichait **£156.75**, neuf ; livraison variable et aucun retour, vendeur privé à Manchester. La [politique livraison](https://carpuride.com/lt/pages/shipping-policy) promet gratuit, expédition sous 1–3 jours et livraison générale 7–15 jours ouvrés (entrepôts locaux dans certaines zones).

- **Aoocci V30(S), 10,26".** [Fiche officielle](https://aoocci.com/products/v30-smart-portable-carplay) : écran IPS 1600×600, CarPlay/Android Auto sans fil, GPS externe, caméra avant 4K, ADAS, option caméra arrière ; **$199** pour V30 (le JSON public expose V30S à $198.99 mais indisponible). Shopify (`luxury-carplay.myshopify.com`), et la route GB conserve USD. La [livraison UK](https://aoocci.com/pages/shipping-policy) est annoncée gratuite, **4–15 jours ouvrés**, après 1–2 jours de traitement, sans taxe/VAT affichée. Aucun prix GBP officiel actuel trouvé ; [Une page promo tierce](https://www.shoppingspout.co.uk/aoocci-voucher-codes) indiquait £148.13, à traiter comme offre à revalider, pas comme prix stable.

- **Repère générique grand retail.** [B&Q marketplace](https://www.diy.com/departments/10-26-hd-touch-screen-car-display-with-wireless-carplay-android-auto/8581707892676_BQ.prd) : 10,26", CarPlay/Android Auto sans fil, Bluetooth, support 7–32 V, accessoires de base, **£51.99**, vendu/expédié par BULELAND UK LTD, en ligne uniquement. C’est un comparable d’intention/format, mais garantie affichée d’un mois et vendeur tiers.

Les catalogues publics Tam’s Factory, Apex Automotive Customs et Control Customs contrôlés dans la fenêtre ne montraient pas de SKU portable 9–10" avec prix : je classe cette inspiration comme extension hors preuve TT. Les offres visibles prouvent un produit réel et sourceable en pratique, mais les écarts de prix (générique £40–80, Carpuride exact £156.75, officiel en USD) impliquent une différenciation par marque, caméra, double Bluetooth, garantie et SAV ; Shopify seul ne prouve pas du dropshipping.
