# Sourcing Q4 — échiquiers bois / bols chantants cristal

**Périmètre API (07/09/2026)** — 2 recherches de 20 résultats en `en_GB/GB/GBP`, 4 `product_get`, 3 frets directs GBP. Aucun achat ni contact fournisseur.

**Résultat : TECHNICAL_WATCH.** Deux échiquiers ont une économie et un délai compatibles, mais le compte exact de 32 pièces n’est pas écrit dans les fiches vérifiées. Le bol sous budget est un bol unique avec accessoires, pas un kit multi-bols accordés.

1. [1005008086495961](https://www.aliexpress.com/item/1005008086495961.html?skuId=12000043641691985) — SKU `12000043641691985`, **chess set**, 39 cm/15 in, bois, £35.19, stock déclaré 10, 26 ventes. Le titre déclare set pliable et reines supplémentaires ; le `product_get` ne donne pas le nombre exact de pièces. Fret direct CN £1.99, **4–8 jours**, rendu **£37.18**.

2. [1005012070192886](https://www.aliexpress.com/item/1005012070192886.html?skuId=12000057442920193) — SKU `12000057442920193`, **1 set**, 45 cm/17.7 in, bois, roi acrylique 9 cm selon titre, £95.79, stock 987, 14 ventes. Le nombre exact de pièces n’est pas documenté dans le texte. Fret direct CN £1.99, **6–10 jours**, rendu **£97.78**.

3. [1005009424303397](https://www.aliexpress.com/item/1005009424303397.html?skuId=12000049055056832) — SKU `12000049055056832`, **5inch A4**, cristal, £121.79, stock 50. L’accessoire `Mallet and oring` est déclaré ; il s’agit d’un seul bol/tone, pas d’un set multi-bols. Fret standard gratuit **11–18 jours**, ou Premium £36.42, 11–16 jours, rendu £158.21 : délai hors cible ≤13 jours.

Le même contrôle a trouvé un véritable SKU **7-piece Set** de bols, mais à £1,539.19 (stock 14), donc hors cible. Les champs `delivery_time=7` des fiches ne valident pas la livraison ; les fenêtres directes ci-dessus font foi. Vérifier physiquement les 32 pièces et le kit de chaque échiquier avant toute offre.
