# Contrôle commercial UK — 07/09/2026

Lecture publique bornée des cinq domaines demandés. Les montants sont ceux affichés en GBP au moment du contrôle ; je sépare les cas où le TTC n’est pas explicitement confirmé. Shopify n’est qu’un marqueur technique et ne prouve pas un modèle dropship. Les spécifications indiquent une comparabilité pratique, mais le matching exact fournisseur/SKU reste à faire.

## MuscleIQ — haltères réglables

- [40kg Adjustable Dumbbells Pair](https://muscleiq.co.uk/products/40kg-adjustable-dumbbell-pair) : **£269.99 TTC** (taxes incluses), en stock, paire ; la page annonce chaque haltère réglable de 5 à 40 kg, 17 réglages, avec sa base de rangement. Le texte “features” contient toutefois une incohérence (2,5–24 kg) à clarifier avant sourcing.
- Livraison publique : traitement le jour même avant 13h, majorité UK mainland en 1 jour ouvré, livraison gratuite UK.
- **Shopify confirmé** : HTML public `Shopify.shop`/`cdn.shopify.com`, [endpoint products.json](https://muscleiq.co.uk/products.json) HTTP 200. Forme très générique (dial/plaques acier + bases), donc comparable en pratique ; la page ne prouve pas l’origine ni la qualité fournisseur.

## GymSets — haltères réglables

- [Premium Adjustable Dumbbells 1kg Increment](https://gymsets.co.uk/products/chrome-adjustable-dumbbells) : variante sélectionnée **2 × 32 kg**, **£399.99 TTC** (prix hors taxe affiché séparément £333.33), 2 haltères, 2 supports, plus de 30 niveaux/poids, incréments de 1 kg. La page est actuellement **Sold out**.
- Livraison annoncée : dispatch le jour même selon l’heure de commande, transit 1–3 jours ouvrés ; une autre section promet 1–2 jours dans la plupart des cas.
- **Shopify confirmé** : marqueurs publics `Shopify.shop`/`cdn.shopify.com`, [products.json](https://gymsets.co.uk/products.json) HTTP 200. Produit à géométrie standard et donc comparable/sourceable en pratique, sans conclusion sur le fulfilment.

## Allendale Ultrasonics — nettoyeurs 2–6 L

- [2 Litre 50W Digital Control](https://www.allendale-ultrasonics.co.uk/products/2-litre-digital-ultrasonic-cleaner-50w) : **£84.54 TTC** (“Incl. VAT”), en stock ; cuve 2 L, 50 W ultrasons/100 W chauffage, couvercle inox, câble secteur et manuel ; panier vendu séparément.
- [6 Litre 220V Dial Control Heated Bath](https://www.allendale-ultrasonics.co.uk/products/6-litre-dial-ultrasonic-cleaner-tank-with-heated-bath-220v) : **£197.35 TTC**, en stock ; cuve inox 6 L, minuterie/température, robinet, machine + cuve + manuel ; panier non inclus.
- Livraison UK publique : expédition le jour même avant 14h30, délai **1–4 jours ouvrés**, coût calculé au panier. **Shopify confirmé** (`Shopify.shop`, `cdn.shopify.com`, [products.json](https://www.allendale-ultrasonics.co.uk/products.json) HTTP 200). Catégorie très standard/sourceable ; l’offre Allendale est une référence UK, pas une preuve d’un fournisseur identique.

## AmScope UK — microscope optique éducatif complet

- [M150C-E monoculaire 40×–1000× avec caméra USB](https://amscope.co.uk/products/40x-1000x-led-coarse-fine-focus-science-student-microscope-1-3mp-usb-camera) : **£160.99 affiché**, en stock au contrôle. Kit étudiant complet : tête monoculaire, trois objectifs 4/10/40×, oculaires WF10×/25×, platine à clips, condenseur à diaphragme, éclairage LED, caméra USB + logiciel, adaptateur secteur, housse et manuel.
- **TTC à confirmer** : la page ne dit pas “tax included” et l’[aide](https://amscope.co.uk/pages/help) indique que la TVA peut être demandée après achat direct. Livraison UK gratuite au-dessus de £100 ; l’aide donne des délais variables (traitement 5–7 jours puis réception 3–10 jours), à revalider au checkout.
- **Shopify confirmé** : marqueurs publics et [products.json](https://amscope.co.uk/products.json) HTTP 200. Marque/fabricant AmScope, donc comparable générique (microscope monoculaire + caméra) mais le SKU exact n’est pas à traiter comme produit générique établi.

## First Light Optics — télescope débutant 70–90 mm

- [Celestron AstroMaster 90EQ](https://www.firstlightoptics.com/beginner-telescopes/astromaster-90eq-telescope.html) : **£174.00**, 90 mm, **2 en stock** au contrôle ; tube optique, monture/trépied préassemblés, oculaires 20 et 10 mm, renvoi image droite, chercheur point rouge, manuel. Prix UK traité comme TTC : le site indique que la TVA est retirée au checkout uniquement pour les clients non-UK.
- Livraison UK : expédition 1–2 jours pour la fiche, livraison habituelle **1–3 jours ouvrés** ([politique](https://www.firstlightoptics.com/delivery-information.html)), généralement £3–6 petit colis / £9 moyen.
- **Plateforme différente** : marqueur public **Bluepark** dans le pied de page ; [products.json](https://www.firstlightoptics.com/products.json) renvoie 404. C’est un produit de marque Celestron ; une copie générique 90 mm est comparable, mais le SKU et la distribution de marque ne sont pas interchangeables.

### Lecture exploitable

Les références les plus directement comparables dans la fenêtre £65–400 sont MuscleIQ (£269.99), Allendale 2 L/6 L (£84.54/£197.35), GymSets (£399.99 mais épuisé), AmScope (£160.99 hors statut TVA clair) et AstroMaster 90EQ (£174). Les deux points à lever avant décision sont la disponibilité GymSets et la TVA/délai AmScope ; Shopify reste seulement un signal de stack.
