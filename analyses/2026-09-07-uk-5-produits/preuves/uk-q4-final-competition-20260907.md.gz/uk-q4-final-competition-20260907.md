# Concurrence UK finale — échecs bois / bols chantants (07/09/2026)

## Contrôle Google

Deux appels DataForSEO `serp/google/organic/live/advanced`, UK (`location_code=2826`, anglais, desktop Windows, profondeur 100), ont été effectués le 07/09/2026. Preuves brutes : [`chess-serp.json`](/tmp/uk-q4-final-competition-20260907/chess-serp.json) et [`crystal-bowls-serp.json`](/tmp/uk-q4-final-competition-20260907/crystal-bowls-serp.json), coût total **$0,004**.

- **`chess set`**, 11:32:59 UTC : organiques Regency Chess, chess.co.uk/London Chess Centre, ChessBaron, Jaques London, etc. Les cartes produits grand public sont Argos £6–20, John Lewis folding £35, LEGO £64.99. Aucun élément `paid`/annonce texte n’a été retourné.
- **`crystal singing bowls`**, 11:32:57 UTC : organiques Sound Therapy Shop, The Sound Healing Spa, Crystal Singing Bowls UK, Amazon, IntoMusicStore, Aura Sounds. Les cartes populaires vont de Thomann £85–193, Amazon sets £159.99–329.99, Pures Music £68.67 à Sunreed £369.57. Aucun élément `paid`/annonce texte n’a été retourné.

Le endpoint `live` ne fournit pas un historique d’août : ces contrôles prouvent seulement l’état de la SERP du 7 septembre dans la fenêtre août–septembre, pas l’absence d’annonces pendant tout le mois d’août.


## Google Ads Transparency — historique 01/08–07/09

Trois appels DataForSEO `serp/google/ads_search/live/advanced` ont ciblé `chess.co.uk`, `thebritishchesscompany.co.uk` et `soundtherapyshop.co.uk`, avec `location_code=2826`, Search texte, profondeur 20, du 01/08/2026 au 07/09/2026. Coût total **$0,006**. Les JSON bruts et le tableau complet des creative URLs sont dans [`ads-creatives.md`](/tmp/uk-q4-final-competition-20260907/ads-creatives.md), avec [`chess-ads.json`](/tmp/uk-q4-final-competition-20260907/chess-ads.json), [`british-chess-ads.json`](/tmp/uk-q4-final-competition-20260907/british-chess-ads.json) et [`soundtherapy-ads.json`](/tmp/uk-q4-final-competition-20260907/soundtherapy-ads.json).

- **chess.co.uk** : 36 creatives retournées, toutes sous l’annonceur affiché **Chess & Bridge Limited** (`AR14317334538471079937`). Les URLs exactes sont en annexe ; les `last_shown` vont du 05/08 au 07/09/2026, le plus récent étant 07/09/2026 08:18:06 UTC.
- **thebritishchesscompany.co.uk** : 1 creative, annonceur affiché **CARMELO MICELI** (`AR09558183669793816577`), [creative CR05246418292842692609](https://adstransparency.google.com/advertiser/AR09558183669793816577/creative/CR05246418292842692609?region=GB), dernière diffusion retournée 07/09/2026 01:49:25 UTC (première 16/01/2025). Le libellé annonceur diffère du domaine ; aucune propriété ou relation supplémentaire n’est inférée.
- **soundtherapyshop.co.uk** : `40102 / No Search Results`, 0 item. Cela ne permet pas d’inférer l’absence de campagne.

## Boutiques spécialistes et offres vérifiables

- [London Chess Centre / chess.co.uk — Luxury Folding Wooden Chess Set](https://chess.co.uk/products/luxury-folding-wooden-chess-set) : **£79.95 TTC** (prix barré £99.95). Ensemble pliant Staunton, acacia/boxwood, roi 76 mm, compartiments de rangement. HTML public : `Shopify.shop = chess-co-uk.myshopify.com`, GBP/GB. La [politique livraison](https://chess.co.uk/policies/shipping-policy) annonce Royal Mail ou coursier et vise **3–5 jours ouvrés UK**. Leur collection monte aussi à £225–275 pour des sets bois plus premium. Boutique spécialiste et preuve d’offre réelle, mais ce modèle reste un produit d’introduction.

- [The British Chess Company — 17″ Grandmaster Walnut Chess Set](https://www.thebritishchesscompany.co.uk/products/15-75-grandmaster-walnut-chess-set) : **£99.95 TTC**, offre éventuelle `DISCOUNT15`. Plateau noyer/érable 17″, pièces Staunton 3″ lestées et feutrées. HTML public : `Shopify.shop = typz3v-iz.myshopify.com`, GBP/GB ; produit accessible avec bouton Add to cart. Promesse **Fast UK Delivery** et retours 30 jours, sans délai UK chiffré trouvé sur la fiche. Le positionnement bois/luxe est déclaré par le site, mais l’identité artisanale/origine des pièces n’est pas documentée publiquement.

- [Sound Therapy Shop UK — Root Chakra Sharp Note C# 12″](https://soundtherapyshop.co.uk/products/sharp-note-c-12-crystal-singing-bowl) : **£291 TTC**, en stock. Quartz australien haute pureté, accordage 432 Hz, finition mate, maillet caoutchouc et anneau inclus ; variante avec assurance £299.73. HTML public : `Shopify.shop = soundtherapyshopuk.myshopify.com`, GBP/GB. La [livraison](https://soundtherapyshop.co.uk/pages/delivery-information) indique expédition directe de l’entrepôt Rainbow Sounds, livraison UK **2–3 jours ouvrés**, signature obligatoire et suivi DPD généralement ; assurance optionnelle pour les bols. C’est une offre spécialisée réelle, mais la chaîne d’approvisionnement affichée est Rainbow Sounds, pas une fabrication propre démontrée.

## Comparables fournisseur

Les prix publics indicatifs AliExpress précédemment capturés ne sont pas repris dans ce rapport : root dispose des SKU et frets API exacts pour cette étape. Aucun verdict de coût rendu, de marge ou d’équivalence produit ne doit utiliser ces anciennes bornes publiques.

**Décision.** Les deux boutiques d’échecs rendent un prix £80–100 crédible pour un set bois complet, mais le SERP grand public descend à £6–65 : un angle “luxe” doit être défendu par matière, lestage, finition, emballage et SAV. Le bol spécialisé à £291 est au-dessus des cartes Thomann £85–193 et des autres offres visibles ; la marge peut exister seulement avec une preuve de qualité, d’accordage, de casse/assurance et de livraison. Les SKU/frets fournisseur exacts doivent venir du fichier API de root. Aucune des trois offres ne prouve une origine TT ou un fulfillment dropshipping ; je les classe **extension hors filtre TT / concurrence observée**, Shopify étant seulement un marqueur de plateforme.
