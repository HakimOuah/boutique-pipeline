# AliExpress — télescope d’initiation 80–90 mm (GB)
Date de contrôle : 07/09/2026. Contrôle lecture seule via API AliExpress, destination GB, devise GBP. Deux recherches texte API (« 80mm telescope », « 90mm telescope »), trois fiches `product_get`. Les journaux bruts sont dans `search-raw.log` et `gets-raw.log`.

## Résultat

**Aucune référence ne satisfait simultanément : 80–90 mm réels, kit complet avec trépied + oculaire, prix <£85 rendu GB et délai ≤10 jours.** Il ne faut donc pas forcer un sourcing ni valider un prix UK £149–174 sur cette passe.

| Référence API | Ce que la fiche confirme | Prix GBP / délai GB | Décision |
|---|---|---:|---|
| [1005005663560784](https://www.aliexpress.com/item/1005005663560784.html) — Skyoptikst | La description distingue **T80-600OTA : diamètre effectif 80 mm, focale 600 mm (f/7.5)** et **T90-500OTA : 90 mm, focale 500 mm (f/5.6)**. Chaque emballage liste tube principal, collier, chercheur 5×20 et adaptateur 2"→1.25", **sans trépied ni oculaire**. | T80/600 Chine, SKU 12000034075505145 : **£139.99** ; T90/500 Chine, SKU 12000034075505150 : **£152.59** ; `delivery_time=5`, GB. Prix `price_include_tax=true`. | **Rejet** : ouverture/focale réelles, mais OTA seule et déjà >£85 avant fret. |
| [1005010562031224](https://www.aliexpress.com/item/1005010562031224.html) | Le titre marketing « 90X » ne correspond pas à l’ouverture : description API = **ouverture active 50 mm, focale 360 mm**, oculaires H20/H6, trépied 34 cm. Kit 1 télescope + 1 trépied. | **£10.99**, `delivery_time=7`, GB, taxe incluse. | **Rejet** : kit et délai passent, mais ce n’est pas un 80–90 mm ; le « 90X » est un grossissement marketing. |
| [1005008251626809](https://www.aliexpress.com/item/1005008251626809.html) | Recherche : réfracteur **60 mm / 500 mm**, trépied réglable et support téléphone. La fiche API renvoie deux variantes noires/bleues ; la description détaillée ne documente pas davantage le kit. | SKU noir 12000044379957524 : **£150.59** ; bleu 12000044379957525 : **£153.79** ; `delivery_time=7`, GB, taxe incluse. | **Rejet** : 60 mm, prix >£85 avant fret, contenu optique incomplet dans la preuve retournée. |

## Lecture commerciale

L’API confirme bien des ouvertures et focales 80/90 mm sur le premier produit, mais uniquement sur une **OTA** à £139.99–£152.59. Le kit bon marché qui affiche « 90X » est en réalité 50/360 mm. Le seul kit voisin retourné (60/500 mm) est déjà à £150.59–£153.79.

Le coût rendu inférieur à £85 et le délai ≤10 jours ne sont donc pas démontrés pour un produit complet 80–90 mm. Aucun sondage de fret n’a été lancé : les trois candidats échouent déjà sur un critère dur (kit, ouverture ou prix avant fret). Les prix AliExpress ne constituent pas une preuve de livraison commerciale tant qu’un SKU admissible n’est pas identifié et que le fret GB n’est pas sondé.

**Verdict : NO-GO sourcing sur cette passe.** Le prix UK £149–174 peut être une hypothèse de retail, mais aucun coût fournisseur admissible ne le soutient ici ; le Celestron 90EQ ne doit pas servir d’identité de produit.
