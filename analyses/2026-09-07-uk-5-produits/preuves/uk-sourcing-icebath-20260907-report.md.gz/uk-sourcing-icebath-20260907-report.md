# Sourcing UK — bain froid portable sans groupe froid — 7 septembre 2026

Contrôle borné AliExpress, destination GB : 4 fiches `product_get`, puis 4 sondes de fret direct `METHOD_FREIGHT_QUERY` en GBP. Aucun chiller, mini-bol visage, achat ou contact fournisseur.

## Offre complète retenue

**SucceBuy Ice Bath Tub**, [produit 1005012520238299](https://www.aliexpress.com/item/1005012520238299.html), Shuerle273 Store (CN). SKU `12000058583359698`, variante `75x80`, stock déclaré **997**, prix **£33.59**. La description API déclare **330 L**, 850 × 750 mm, couvercle thermique, pompe à air manuelle, coussin d’eau et sac de transport. La propriété produit indique « Cover: with lid ».

Fret direct GB choisi : `CAINIAO_STANDARD`, **£44.60**, CN, suivi, fenêtre API **6–13 jours**, `Sep 13 - 20`. Coût rendu API : **£78.19**. Options premium : £87.79 (6–11 jours); option heavy : £40.90 mais 10–41 jours. Le coût cible <£55 n’est donc pas atteint, même si le prix produit seul est bas.

## Autres fiches contrôlées

- `1005010151127666`, £64.99, stock 291 : fiche sans volume, couvercle ou pompe explicités; description contradictoire (« no inflation » puis « inflatable »). Fret direct £1.99 mais **26–43 jours**; le `delivery_time=7` de `logistics_info_dto` n’est pas retenu.
- `1005010161523574`, £55.99, stock 993 : volume déclaré 95 gallons, siège d’eau et 8 barres inox, mais couvercle/pompe non établis. Fret £44.60, 6–13 jours; total £100.59.
- `1005009944233727`, £51.59, stock 22 : propriété « with lid », volume et pompe absents de la description. Fret £1.99 mais **25–42 jours**; total £53.58, non exploitable pour le délai.

`TECHNICAL_WATCH` : une offre complète est documentée, mais elle est au-dessus du coût rendu cible et le délai standard est borderline. Les claims de volume, contenu, stock et délai restent déclaratifs; aucun échantillon ni contrôle de livraison n’a été réalisé.

Voir `evidence.json`, `details.jsonl` et `freight-gbp.jsonl` pour les réponses brutes.
