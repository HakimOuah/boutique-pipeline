## chess.co.uk

- API task status: `20000` — Ok.; result items: `36`; check URL: https://adstransparency.google.com/?region=GB&domain=chess.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07

| # | Annonceur | Creative URL | Première diffusion | Dernière diffusion |
|---:|---|---|---|---|
| 1 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR14075494756918493185](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR14075494756918493185?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-07 08:18:06 +00:00 |
| 2 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR17082245642513809409](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR17082245642513809409?region=GB) | 2021-10-25 07:00:00 +00:00 | 2026-09-07 08:10:49 +00:00 |
| 3 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR11343161203154223105](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR11343161203154223105?region=GB) | 2024-02-08 08:00:00 +00:00 | 2026-09-07 06:18:10 +00:00 |
| 4 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR02979010928781033473](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR02979010928781033473?region=GB) | 2021-10-25 07:00:00 +00:00 | 2026-09-06 21:09:46 +00:00 |
| 5 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR08887346611798147073](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR08887346611798147073?region=GB) | 2021-10-25 07:00:00 +00:00 | 2026-09-06 21:08:23 +00:00 |
| 6 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR10290113716997324801](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR10290113716997324801?region=GB) | 2022-11-17 21:35:28 +00:00 | 2026-09-06 20:25:11 +00:00 |
| 7 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR14062516121664225281](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR14062516121664225281?region=GB) | 2024-02-10 08:00:00 +00:00 | 2026-09-06 20:23:59 +00:00 |
| 8 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR12602078806954475521](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR12602078806954475521?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-06 19:55:40 +00:00 |
| 9 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR00775674770149605377](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR00775674770149605377?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-06 18:54:55 +00:00 |
| 10 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR09339235376734142465](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR09339235376734142465?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-06 18:52:21 +00:00 |
| 11 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR06006452544446922753](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR06006452544446922753?region=GB) | 2024-03-22 14:39:43 +00:00 | 2026-09-06 18:14:28 +00:00 |
| 12 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR05591369862531252225](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR05591369862531252225?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-06 17:55:30 +00:00 |
| 13 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR09463253330500255745](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR09463253330500255745?region=GB) | 2024-03-21 12:59:59 +00:00 | 2026-09-06 17:32:21 +00:00 |
| 14 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR00958513177207767041](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR00958513177207767041?region=GB) | 2021-10-25 07:00:00 +00:00 | 2026-09-06 16:58:10 +00:00 |
| 15 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR02739792589107494913](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR02739792589107494913?region=GB) | 2024-03-21 12:58:02 +00:00 | 2026-09-06 15:22:52 +00:00 |
| 16 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR03204917111809900545](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR03204917111809900545?region=GB) | 2024-02-07 08:00:00 +00:00 | 2026-09-06 13:29:12 +00:00 |
| 17 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR07060928725705031681](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR07060928725705031681?region=GB) | 2024-02-17 08:00:00 +00:00 | 2026-09-06 12:59:24 +00:00 |
| 18 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR02266176529513840641](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR02266176529513840641?region=GB) | 2024-11-11 18:17:40 +00:00 | 2026-09-06 09:53:18 +00:00 |
| 19 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR13603573628858793985](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR13603573628858793985?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-06 01:06:29 +00:00 |
| 20 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR08997650992686170113](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR08997650992686170113?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-05 16:36:36 +00:00 |
| 21 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR17848241360264495105](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR17848241360264495105?region=GB) | 2024-02-21 15:43:22 +00:00 | 2026-09-02 15:17:31 +00:00 |
| 22 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR04984287084329041921](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR04984287084329041921?region=GB) | 2024-02-12 16:20:29 +00:00 | 2026-09-02 14:35:13 +00:00 |
| 23 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR07212261236954628097](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR07212261236954628097?region=GB) | 2024-02-11 14:31:53 +00:00 | 2026-09-02 14:24:34 +00:00 |
| 24 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR11509969349154701313](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR11509969349154701313?region=GB) | 2024-02-21 08:00:00 +00:00 | 2026-09-02 14:24:34 +00:00 |
| 25 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR01274411406262796289](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR01274411406262796289?region=GB) | 2024-02-08 08:00:00 +00:00 | 2026-09-02 12:59:20 +00:00 |
| 26 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR11845449717091663873](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR11845449717091663873?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-02 12:39:39 +00:00 |
| 27 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR01999660236700385281](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR01999660236700385281?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-02 12:39:39 +00:00 |
| 28 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR18066287263515410433](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR18066287263515410433?region=GB) | 2024-02-20 15:42:41 +00:00 | 2026-09-02 10:42:14 +00:00 |
| 29 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR05517793877295104001](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR05517793877295104001?region=GB) | 2024-02-07 08:00:00 +00:00 | 2026-09-02 10:14:10 +00:00 |
| 30 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR02763688601731465217](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR02763688601731465217?region=GB) | 2024-02-07 08:00:00 +00:00 | 2026-09-02 10:14:10 +00:00 |
| 31 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR04054312530284118017](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR04054312530284118017?region=GB) | 2024-02-07 17:35:31 +00:00 | 2026-09-02 09:17:17 +00:00 |
| 32 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR16031862101232320513](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR16031862101232320513?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-09-01 15:01:36 +00:00 |
| 33 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR08630907841269465089](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR08630907841269465089?region=GB) | 2024-02-09 08:00:00 +00:00 | 2026-09-01 10:34:00 +00:00 |
| 34 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR01554100913528897537](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR01554100913528897537?region=GB) | 2024-02-07 08:00:00 +00:00 | 2026-09-01 10:02:33 +00:00 |
| 35 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR17312752457071198209](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR17312752457071198209?region=GB) | 2024-02-06 08:00:00 +00:00 | 2026-08-21 19:07:45 +00:00 |
| 36 | Chess & Bridge Limited (`AR14317334538471079937`) | [CR03231247735235543041](https://adstransparency.google.com/advertiser/AR14317334538471079937/creative/CR03231247735235543041?region=GB) | 2024-02-14 08:00:00 +00:00 | 2026-08-05 14:24:39 +00:00 |

## thebritishchesscompany.co.uk

- API task status: `20000` — Ok.; result items: `1`; check URL: https://adstransparency.google.com/?region=GB&domain=thebritishchesscompany.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07

| # | Annonceur | Creative URL | Première diffusion | Dernière diffusion |
|---:|---|---|---|---|
| 1 | CARMELO MICELI (`AR09558183669793816577`) | [CR05246418292842692609](https://adstransparency.google.com/advertiser/AR09558183669793816577/creative/CR05246418292842692609?region=GB) | 2025-01-16 21:34:38 +00:00 | 2026-09-07 01:49:25 +00:00 |

## soundtherapyshop.co.uk

- API task status: `40102` — No Search Results.; result items: `0`; check URL: https://adstransparency.google.com/?region=GB&domain=soundtherapyshop.co.uk&platform=SEARCH&format=TEXT&start-date=2026-08-01&end-date=2026-09-07

Aucun résultat retourné par l’endpoint pour cette cible/plage ; cela ne permet pas d’inférer l’absence de campagne.
