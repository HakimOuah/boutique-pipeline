# Sourcing UK abayas — 7 septembre 2026

Passe AliExpress en lecture seule, destination GB, devise produit GBP. Trois requêtes texte ont renvoyé 10 résultats chacune; cinq fiches ont été ouvertes; trois SKU ont été sondés en fret. Les trois offres retenues viennent de trois vendeurs distincts.

| Offre | Produit / SKU exact | Prix GBP | Stock déclaré | Fret GB / délai API | Total GBP* |
|---|---|---:|---:|---|---:|
| Ouverte | [1005012385271194](https://www.aliexpress.com/item/1005012385271194.html), Black / M, SKU 12000058264898367 | £50.99 | 998 | £12.39, standard, CN; 6–13 j, `Sep 13 - 20` | £63.38 |
| Ensemble brodé 3 pièces | [1005012289841477](https://www.aliexpress.com/item/1005012289841477.html), Beige 3pcs set / M, SKU 12000057978139381 | £42.39 | 100 | £18.48, standard, CN; 6–13 j, `Sep 13 - 20` | £60.87 |
| Brodée | [1005012471812405](https://www.aliexpress.com/item/1005012471812405.html), Black / M, SKU 12000058450979863 | £54.99 | 50 | £1.99, Selection Premium, CN; 6–10 j, `Sep 13 - 17` | £56.98 |

Les titres API décrivent respectivement une abaya ouverte doublée, un ensemble avec abaya/inner/hijab et une abaya brodée doublée avec ceinture. Prix SKU `offer_sale_price`, taxes incluses selon le drapeau API. *Total = prix produit GBP + fret GBP renvoyé par l’appel direct `METHOD_FREIGHT_QUERY` avec `currency=GBP`, `locale=en_GB`. L’API renvoie les dates sans année; l’appel a été fait le 07/09/2026. Les totaux sont un screening, pas un devis contractuel.

## Comparaison concurrentielle courte

Abayas Boutique affiche l’Elsara à £85, en 3 pièces (abaya ouverte, hijab, ceinture), avec crinkle nida et embellissements en cascade: repère direct dans la cible £69–119. La Nayara est affichée €131.97, en 2 pièces, avec broderie main et panneaux chiffon; elle montre un niveau premium supérieur et une fabrication à la commande. Pages lues: [Elsara](https://abayasboutique.com/product/elsara-embellished-open-abaya/) et [Nayara](https://abayasboutique.com/product/nayara/).

## Lecture technique

`TECHNICAL_WATCH`: trois SKU exacts ont une réponse fret GB, un stock positif déclaré et un coût rendu API d’environ £56.98–£63.38, compatible avec une vente visée £69–119 avant publicité, retours et TVA. Les vendeurs sont CN; les fiches affichent 0 évaluation sur les deux références principales et 4–5 ventes seulement sur l’ensemble 3 pièces. Aucun échantillon n’a été reçu. La qualité du tissu/broderie, le contenu réel des ensembles, le sizing, la conformité, la facture TVA, les retours UK et la tenue du délai restent `MANQUANT`. Aucun nom de marque tierce n’apparaît dans les titres retenus, ce qui ne constitue pas une clearance IP.

Aucune commande, panier, message fournisseur ou publication n’a été effectué. Voir `evidence.json` pour les réponses brutes et les paramètres d’appel.
